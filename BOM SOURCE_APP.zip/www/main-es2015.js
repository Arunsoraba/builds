(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-action-sheet.entry.js",
		"common",
		0
	],
	"./ion-alert.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-alert.entry.js",
		"common",
		1
	],
	"./ion-app_8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-app_8.entry.js",
		"common",
		2
	],
	"./ion-avatar_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-avatar_3.entry.js",
		"common",
		3
	],
	"./ion-back-button.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-back-button.entry.js",
		"common",
		4
	],
	"./ion-backdrop.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-backdrop.entry.js",
		5
	],
	"./ion-button_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-button_2.entry.js",
		"common",
		6
	],
	"./ion-card_5.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-card_5.entry.js",
		"common",
		7
	],
	"./ion-checkbox.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-checkbox.entry.js",
		"common",
		8
	],
	"./ion-chip.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-chip.entry.js",
		"common",
		9
	],
	"./ion-col_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-col_3.entry.js",
		10
	],
	"./ion-datetime_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-datetime_3.entry.js",
		"common",
		11
	],
	"./ion-fab_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-fab_3.entry.js",
		"common",
		12
	],
	"./ion-img.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-img.entry.js",
		13
	],
	"./ion-infinite-scroll_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2.entry.js",
		14
	],
	"./ion-input.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-input.entry.js",
		"common",
		15
	],
	"./ion-item-option_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item-option_3.entry.js",
		"common",
		16
	],
	"./ion-item_8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item_8.entry.js",
		"common",
		17
	],
	"./ion-loading.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-loading.entry.js",
		"common",
		18
	],
	"./ion-menu_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-menu_3.entry.js",
		"common",
		19
	],
	"./ion-modal.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-modal.entry.js",
		"common",
		20
	],
	"./ion-nav_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-nav_2.entry.js",
		"common",
		21
	],
	"./ion-popover.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-popover.entry.js",
		"common",
		22
	],
	"./ion-progress-bar.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-progress-bar.entry.js",
		"common",
		23
	],
	"./ion-radio_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-radio_2.entry.js",
		"common",
		24
	],
	"./ion-range.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-range.entry.js",
		"common",
		25
	],
	"./ion-refresher_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-refresher_2.entry.js",
		"common",
		26
	],
	"./ion-reorder_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-reorder_2.entry.js",
		"common",
		27
	],
	"./ion-ripple-effect.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-ripple-effect.entry.js",
		28
	],
	"./ion-route_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-route_4.entry.js",
		"common",
		29
	],
	"./ion-searchbar.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-searchbar.entry.js",
		"common",
		30
	],
	"./ion-segment_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-segment_2.entry.js",
		"common",
		31
	],
	"./ion-select_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-select_3.entry.js",
		"common",
		32
	],
	"./ion-slide_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-slide_2.entry.js",
		33
	],
	"./ion-spinner.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-spinner.entry.js",
		"common",
		34
	],
	"./ion-split-pane.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-split-pane.entry.js",
		35
	],
	"./ion-tab-bar_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab-bar_2.entry.js",
		"common",
		36
	],
	"./ion-tab_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab_2.entry.js",
		"common",
		37
	],
	"./ion-text.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-text.entry.js",
		"common",
		38
	],
	"./ion-textarea.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-textarea.entry.js",
		"common",
		39
	],
	"./ion-toast.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toast.entry.js",
		"common",
		40
	],
	"./ion-toggle.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toggle.entry.js",
		"common",
		41
	],
	"./ion-virtual-scroll.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-virtual-scroll.entry.js",
		42
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n  <!-- <ion-split-pane contentId=\"main-content\"> -->\n    <!-- <ion-menu contentId=\"main-content\" type=\"overlay\">\n      <ion-content>\n        <div class=\"profile\">\n          <div class=\"image_profile\">\n              <ion-icon name=\"person-circle-outline\"></ion-icon>\n          </div>\n          <ion-note>hi@murali.com</ion-note>\n        </div>\n        <ion-list id=\"inbox-list\">\n\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages; let i = index\">\n            <ion-item (click)=\"selectedIndex = i\" routerDirection=\"root\" [routerLink]=\"[p.url]\" lines=\"none\" detail=\"false\" [class.selected]=\"selectedIndex == i\">\n              <ion-icon slot=\"start\" [ios]=\"p.icon + '-outline'\" [md]=\"p.icon + '-sharp'\"></ion-icon>\n              <ion-label>{{ p.title }}</ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n        </ion-list>\n      </ion-content>\n    </ion-menu> -->\n    <ion-router-outlet id=\"main-content\"></ion-router-outlet>\n   \n  <!-- </ion-split-pane> -->\n  <div class=\"spinner_block\" *ngIf=\"spinnerState\">\n    <ion-spinner name=\"bubbles\"></ion-spinner>\n  </div>\n</ion-app>\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/change-email/change-email.component.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/change-email/change-email.component.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header >\r\n    <ion-toolbar class=\"header\">\r\n      <ion-buttons slot=\"start\">\r\n          <ion-button (click)=\"back()\">\r\n            <ion-icon name=\"chevron-back-outline\" ></ion-icon>\r\n          </ion-button>\r\n      </ion-buttons>\r\n      <ion-title>Update Email</ion-title>\r\n    </ion-toolbar>\r\n  </ion-header>\r\n  <ion-content>\r\n      <div class=\"page_container\">\r\n        <div class=\"cust_id\">\r\n          Customer ID : <span >  {{changeEml.customerId}}</span>\r\n        </div>\r\n          <ion-item class=\"form_field\">\r\n              <ion-icon name=\"mail\" slot=\"start\"  class=\"icons\"></ion-icon>\r\n              <ion-label position=\"floating\" class=\"label\" >Email ID</ion-label>\r\n              <ion-input maxlength=\"40\" (ionFocus)=\"clearErr()\" [(ngModel)]=\"changeEml.email\"></ion-input>\r\n            </ion-item>\r\n            <div class=\"error_msg\" [ngClass]=\"{'showError':error}\">\r\n              {{ error }}\r\n             </div>\r\n\r\n            <div class=\"inst_block\">\r\n              <div class=\"title_block\"> Instructions</div>\r\n              <div class=\"inst\"> <ion-icon name=\"star\" class=\"star\"></ion-icon>  <div>Submit new email ID.</div></div>\r\n              <div class=\"inst\"><ion-icon name=\"star\" class=\"star\"></ion-icon> <div>Bank will communicate once your email ID is updated.</div></div>\r\n            </div>\r\n              <div class=\"button_block\">\r\n                  <ion-button [disabled]=\"!changeEml.email\" class=\"button_theme\" expand=\"block\" (click)=\"changeEmail()\">Submit</ion-button>\r\n              </div>\r\n      </div>\r\n    \r\n  </ion-content>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/change-pan/change-pan.component.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/change-pan/change-pan.component.html ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header >\r\n    <ion-toolbar class=\"header\">\r\n      <ion-buttons slot=\"start\">\r\n          <ion-button (click)=\"back()\">\r\n            <ion-icon name=\"chevron-back-outline\" ></ion-icon>\r\n          </ion-button>\r\n      </ion-buttons>\r\n      <ion-title>Update PAN</ion-title>\r\n    </ion-toolbar>\r\n  </ion-header>\r\n  <ion-content>\r\n      <div class=\"page_container\">\r\n        <div class=\"cust_id\">\r\n          Customer ID : <span > {{pan.customerId}}</span>\r\n        </div>\r\n        \r\n          <ion-item class=\"form_field\">\r\n              <ion-icon name=\"mail\" slot=\"start\"  class=\"icons\"></ion-icon>\r\n              <ion-label position=\"floating\" class=\"label\" >PAN Number</ion-label>\r\n              <ion-input [(ngModel)]=\"pan.PANNumber\"  maxlength=\"10\" ></ion-input>\r\n            </ion-item>\r\n            <div class=\"pan_pic_block\">\r\n              <div class=\"label label_text\">PAN Photo</div>\r\n              <div class=\"upload_block\" (click)=\"fileUpload.click()\">\r\n                  <img *ngIf=\"imageFile\" width=\"100%\" height=\"100%\" [src]=\"imageFile\"/>\r\n                  <ion-icon *ngIf=\"!imageFile\" name=\"cloud-upload\"class=\"upload_icon\"></ion-icon>\r\n              </div>\r\n            </div>\r\n            <div class=\"accept_text\">\r\n              <div><ion-checkbox (ionChange)=\"changeCheckbox($event)\" [(ngModel)]=\"acceptTerms\" class=\"checkbox_theme\" ></ion-checkbox></div>\r\n              <div class=\"label\" (click)=\"acceptTerms = !acceptTerms\">I declare the above information is true.</div>\r\n            </div>\r\n              <div class=\"button_block\">\r\n                  <ion-button [disabled]=\"!pan.PANImg || !pan.PANNumber || !acceptTerms || pan.PANNumber.length!=10\" class=\"button_theme\" expand=\"block\" (click)=\"changePan()\">Submit</ion-button>\r\n              </div>\r\n\r\n          \r\n      </div>\r\n      <form [formGroup]=\"form\">\r\n      <div style=\"display:none\" class=\"form-group\">\r\n        <input #fileUpload id=\"avatar\" type=\"file\" accept=\"image/*\" value=\"\" (change)=\"fileChange($event)\">\r\n         </div>\r\n        </form>\r\n\r\n         <!-- <form [formGroup]=\"form\" (ngSubmit)=\"onSubmit()\">\r\n          <div class=\"form-group\">\r\n            <label for=\"name\">Name</label>\r\n            <input type=\"text\" class=\"form-control\" id=\"name\" placeholder=\"Bob\" formControlName=\"name\">\r\n          </div>\r\n          <div class=\"form-group\">\r\n            <label for=\"avatar\">Avatar</label>\r\n            <input type=\"file\" id=\"avatar\" (change)=\"onFileChange($event)\" #fileInput>\r\n            <button type=\"button\" class=\"btn btn-sm btn-default\" (click)=\"clearFile()\">clear file</button>\r\n          </div>\r\n          <button type=\"submit\" [disabled]=\"form.invalid || loading\" class=\"btn btn-success\">Submit <i class=\"fa fa-spinner fa-spin fa-fw\" *ngIf=\"loading\"></i></button>\r\n        </form> -->\r\n\r\n\r\n\r\n  </ion-content>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/dashboard/dashboard.component.html":
/*!******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/dashboard/dashboard.component.html ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header >\n  <ion-toolbar class=\"header\">\n    <!-- <ion-buttons slot=\"start\">\n      <ion-menu-toggle>\n        <ion-button>\n          <ion-icon slot=\"icon-only\" name=\"menu\"></ion-icon>\n        </ion-button>\n      </ion-menu-toggle>\n    </ion-buttons> -->\n    <ion-title>Hi Muralidhar</ion-title>\n    <ion-buttons slot=\"end\">\n        <ion-button (click)=\"logOut()\">\n          <!-- <ion-icon slot=\"icon-only\" name=\"log-out-outline\"></ion-icon> -->\n          <ion-icon slot=\"icon-only\" class=\"logout_icon\" name=\"log-out-outline\"></ion-icon>\n          <!-- <ion-icon name=\"log-out-outline\"></ion-icon> -->\n        </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n\n<div>\n    <ion-slides pager=\"true\" [options]=\"slideOpts\">\n    <ion-slide>\n      <div class=\"slide_image_block\"><img class=\"slide_image\" src=\"../assets/images/slideSample.PNG\"/></div>\n    </ion-slide>\n    <ion-slide>\n        <div class=\"slide_image_block\"><img class=\"slide_image\" src=\"../assets/images/slideSample.PNG\"/></div>\n    \n    </ion-slide>\n    <ion-slide>\n        <div class=\"slide_image_block\"><img class=\"slide_image\" src=\"../assets/images/slideSample.PNG\"/></div>\n    \n    </ion-slide>\n  </ion-slides>\n</div>\n\n<div class=\"options_block\">\n      <ion-row>\n          <ion-col size=\"4\">\n      <div class=\"options\" (click)=\"navigateTo('requestDdPo')\">\n          <div class=\"icon_overlay\">\n            <div class=\"ddIcon action_icons_home\"></div>\n          </div>\n          <div class=\"label_block\">DD Request</div>\n      </div>\n    </ion-col>\n    <ion-col size=\"4\">\n        <div class=\"options\" (click)=\"navigateTo('changePan')\">\n            <div class=\"icon_overlay\">\n                <div class=\"panIcon action_icons_home\"></div></div>\n            <div class=\"label_block\">PAN Update</div>\n        </div>\n      </ion-col>\n      <ion-col size=\"4\">\n          <div class=\"options\" (click)=\"navigateTo('changeEmail')\">\n              <div class=\"icon_overlay\">\n                  <div class=\"emailIcon action_icons_home\"></div></div>\n              <div class=\"label_block\">Email Update</div>\n          </div>\n        </ion-col>\n        <ion-col size=\"4\">\n            <div class=\"options\" (click)=\"navigateTo('pmSchemes')\">\n                <div class=\"icon_overlay\">\n                    <div class=\"pmIcon action_icons_home\"></div></div>\n                <div class=\"label_block\">PM Yojana</div>\n            </div>\n          </ion-col>\n          <ion-col size=\"4\">\n              <div class=\"options\" (click)=\"navigateTo('preApprovedOffers')\">\n                  <div class=\"icon_overlay\">\n                      <div class=\"offersIcon action_icons_home\"></div></div>\n                  <div class=\"label_block\">Pre Approved Offers</div>\n              </div>\n            </ion-col>\n            <ion-col size=\"4\">\n                <div class=\"options\" (click)=\"navigateTo('supportComplaint')\">\n                    <div class=\"icon_overlay\">\n                        <div class=\"supportIcon action_icons_home\"></div></div>\n                    <div class=\"label_block\">Support & Complaint</div>\n                    \n                </div>\n              </ion-col>\n    </ion-row>\n</div>\n<div class=\"myRequests\"> <span  (click)=\"myRequests()\">My Requests</span></div>\n<div class=\"bottom_slide\">\n  <img class=\"botom_ad\" src=\"../assets/images/slideSample.PNG\"/>\n</div>\n    \n\n</ion-content>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.component.html":
/*!**********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.component.html ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header >\n    <ion-toolbar class=\"header\">\n      <!-- <ion-buttons slot=\"start\">\n          <ion-button>\n            <ion-icon name=\"chevron-back-outline\"></ion-icon>\n          </ion-button>\n      </ion-buttons> -->\n      <ion-title>Login</ion-title>\n     \n    </ion-toolbar>\n  </ion-header>\n  <ion-content>\n      <div class=\"page_container\">\n        <div class=\"fingerprint_block\" (click)=\"openFingerPrint()\" >\n          <!-- <div class=\"circle_block\">\n            <div class=\"touch_icon\">\n                <ion-icon name=\"finger-print\"></ion-icon>\n            </div>\n          </div> -->\n          <img src=\"../../assets/images/2x/Group 4@2x.png\"/>\n        </div>\n        <div class=\"useTouchId\">Use Touch ID</div>\n        <div class=\"blur_text\">\n          Now you can just login using Touch ID.\n        </div>\n              <div class=\"button_block\">\n                  <ion-button class=\"button_theme\" expand=\"block\" (click)=\"activate()\">Activate Now</ion-button>\n              </div>\n              <div class=\"skip_button_block\">\n                  <ion-button class=\"skip_btn\" expand=\"block\" (click)=\"skip()\">Skip</ion-button>\n              </div>\n      </div>\n    \n  </ion-content>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/my-requests/my-requests.component.html":
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/my-requests/my-requests.component.html ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header >\n    <ion-toolbar class=\"header\">\n      <ion-buttons slot=\"start\">\n          <ion-button (click)=\"back()\">\n            <ion-icon name=\"chevron-back-outline\" ></ion-icon>\n          </ion-button>\n      </ion-buttons>\n      <ion-title>My Requests</ion-title>\n    </ion-toolbar>\n  </ion-header>\n  <ion-content>\n    <div *ngIf=\"requests.length > 0\">\n      <div class=\"eachItem\" *ngFor=\"let item of requests\" >\n          <ion-item button class=\"\" >\n              <ion-avatar slot=\"start\">\n                  <div class=\"emailIcon listviewImage\" *ngIf=\"REQUEST_TYPE[item.REQTYPE]==REQUEST_TYPE.EMAIL\"></div>  \n                  <div class=\"panIcon listviewImage\" *ngIf=\"REQUEST_TYPE[item.REQTYPE]==REQUEST_TYPE.PAN\"></div>  \n                  <div class=\"ddIcon listviewImage\" *ngIf=\"REQUEST_TYPE[item.REQTYPE]==REQUEST_TYPE.DDPO\"></div>  \n                  <div class=\"pmIcon listviewImage\" *ngIf=\"REQUEST_TYPE[item.REQTYPE]==REQUEST_TYPE.SCHEMES\"></div>  \n              </ion-avatar>\n              <ion-label>\n                <div class=\"labelText\">{{REQUEST_TYPE[item.REQTYPE]}} </div>\n                <div class=\"dateText\"> Date {{item.MOD_DATE}} </div>\n              </ion-label>\n              <div  slot=\"end\" class=\"status\" [style]=\"{'color':COLORS_CODE[item.STATUS]}\">\n                {{REQUEST_STATUS[item.STATUS]}}\n              </div>\n            </ion-item>\n           \n      </div>\n    </div>\n     <div class=\"noRequests\" *ngIf=\"requests.length == 0 && apiResponded\">\n                <div>No Requests</div>\n            </div>\n  </ion-content>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pm-schemes/pm-schemes.component.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pm-schemes/pm-schemes.component.html ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header >\r\n    <ion-toolbar class=\"header\">\r\n      <ion-buttons slot=\"start\">\r\n          <ion-button (click)=\"back()\">\r\n            <ion-icon name=\"chevron-back-outline\" ></ion-icon>\r\n          </ion-button>\r\n      </ion-buttons>\r\n      <ion-title>PM Schemes</ion-title>\r\n    </ion-toolbar>\r\n  </ion-header>\r\n  <ion-content>\r\n      <div class=\"page_container\">\r\n        <div class=\"cust_id\">\r\n          Customer ID : <span > BOM7834347353533</span>\r\n        </div>\r\n        <div class=\"label_text label_padding\"> Account Number</div>\r\n            <ion-item class=\"form_field\">\r\n                <ion-select class=\"slect_box\" [(ngModel)]=\"selectedAccount\" [interfaceOptions]=\"customchooseAccOptions\" interface=\"action-sheet\" placeholder=\"Select Account Number\">\r\n                  <ion-select-option  *ngFor=\"let acc of accounts\" [value]=\"acc\">{{acc}}</ion-select-option>\r\n                </ion-select>\r\n              </ion-item>\r\n            <div class=\"label_text label_padding\"> Scheme</div>\r\n            <!-- https://ionicframework.com/docs/api/select -->\r\n            <ion-item class=\"form_field\">\r\n                <ion-select class=\"slect_box\" [interfaceOptions]=\"customActionSheetOptions\" interface=\"action-sheet\" [(ngModel)]=\"selectedScheme\" (ionChange)=\"onChangeScheme(selectedScheme)\" placeholder=\"Select Scheme\">\r\n                  <ion-select-option *ngFor=\"let scheme of schemes\" class=\"test\" [value]=\"scheme\" [selected]=\"selectedScheme.scheme\">{{scheme.scheme}}</ion-select-option>\r\n                </ion-select>\r\n              </ion-item>\r\n              <div class=\"label_text label_padding\"> Insurance Cover</div>\r\n              <div class=\"scheme_details\">\r\n                {{selectedScheme.totalDisabilityInsurence}} <br/> <br/>\r\n                {{selectedScheme.partialDisabilityInsurence}}\r\n              </div>\r\n              <div class=\"label_text label_padding\"> Premium</div>\r\n              <div class=\"scheme_details\">\r\n                  {{selectedScheme.premium}}\r\n                </div>\r\n              <div class=\"button_block\">\r\n                  <ion-button class=\"button_theme\" expand=\"block\" (click)=\"pmSchemeSubmit()\" [disabled]=\"!selectedAccount\">Submit</ion-button>\r\n              </div>\r\n      </div>\r\n    \r\n  </ion-content>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pre-approved-offers/pre-approved-offers.component.html":
/*!**************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pre-approved-offers/pre-approved-offers.component.html ***!
  \**************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header >\n  <ion-toolbar class=\"header\">\n    <ion-buttons slot=\"start\">\n        <ion-button (click)=\"back()\">\n          <ion-icon name=\"chevron-back-outline\"></ion-icon>\n        </ion-button>\n    </ion-buttons>\n    <ion-title>Pre Approved Offers</ion-title>\n   \n  </ion-toolbar>\n</ion-header>\n<ion-content *ngIf=\"offers.length > 0 \">\n    <div class=\"page_container\" >\n      <div *ngFor=\"let ofr of offers\" class=\"each_offer\">\n        <div class=\"listItems\" expand=\"block\">\n          <div class=\"labelText\">{{ofr.NAME}}</div>\n          <div> {{ofr.DESCRIPTION}}</div>\n          <!-- <div class=\"bottomOverlay\"></div> -->\n      </div>\n    </div>\n    </div>\n\n    <!-- <ion-list>\n        <ion-item *ngFor=\"let ofr of offers\" class=\"each_offer\">\n          <ion-label>{{ofr.name}}</ion-label>\n        </ion-item>\n        </ion-list> -->\n  <!-- <div class=\"background_layout\">\n    <div class=\"first_block\"> </div>\n    <div class=\"second_block\"> </div>\n  </div> -->\n\n \n</ion-content>\n<div class=\"noRequests\" *ngIf=\"offers.length == 0 && apiResponded\">\n    <div>No Offers Found</div>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.component.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.component.html ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header >\n    <ion-toolbar class=\"header\">\n      <!-- <ion-buttons slot=\"start\">\n          <ion-button>\n            <ion-icon name=\"chevron-back-outline\"></ion-icon>\n          </ion-button>\n      </ion-buttons> -->\n      <ion-title>Register Now</ion-title>\n     \n    </ion-toolbar>\n  </ion-header>\n  <ion-content>\n      <div class=\"page_container\">\n          <ion-item class=\"form_field\">\n              <ion-icon name=\"person-circle-outline\" slot=\"start\"  class=\"icons\"></ion-icon>\n              <ion-label position=\"floating\" class=\"label\" >Account Number</ion-label>\n              <ion-input maxlength=\"14\" (ionFocus)=\"clearErr()\" type=\"tel\"  [(ngModel)]=\"user.accountNo\"></ion-input>\n            </ion-item>\n            <ion-item  class=\"form_field\">\n                <ion-icon name=\"call-outline\" slot=\"start\"  class=\"icons\"></ion-icon>\n                <ion-label position=\"floating\"  class=\"label\">Mobile Number</ion-label>\n                <ion-input maxlength=\"10\" (ionFocus)=\"clearErr()\" type=\"tel\" [(ngModel)]=\"user.mobileNo\"></ion-input>\n              </ion-item>\n             <div class=\"error_msg\" [ngClass]=\"{'showError':error}\">\n              {{ error }}\n             </div>\n              <div class=\"button_block\">\n                  <ion-button class=\"button_theme\" expand=\"block\" (click)=\"registerUser()\" [disabled]=\"!user.mobileNo || !user.accountNo\">Register</ion-button>\n              </div>\n      </div>\n    \n  </ion-content>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/request-dd-po/request-dd-po.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/request-dd-po/request-dd-po.component.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header >\r\n    <ion-toolbar class=\"header\">\r\n      <ion-buttons slot=\"start\">\r\n          <ion-button (click)=\"back()\">\r\n            <ion-icon name=\"chevron-back-outline\" ></ion-icon>\r\n          </ion-button>\r\n      </ion-buttons>\r\n      <ion-title>DD/PO Requests</ion-title>\r\n    </ion-toolbar>\r\n  </ion-header>\r\n  <ion-content>\r\n      <div class=\"page_container\">\r\n        <div class=\"cust_id\">\r\n          Customer ID : <span > {{userDetails.customerId}}</span>\r\n        </div>\r\n        <div class=\"label_text label_padding_1\"> Account Number</div>\r\n        <ion-item class=\"form_field\">\r\n            <ion-select class=\"slect_box\" [(ngModel)]=\"ddpo.accountNumber\" [interfaceOptions]=\"customchooseAccOptions\" interface=\"action-sheet\" placeholder=\"Select Account Number\">\r\n              <ion-select-option  *ngFor=\"let acc of accounts\" [value]=\"acc\">{{acc}}</ion-select-option>\r\n            </ion-select>\r\n          </ion-item>\r\n          <div class=\"label_text label_padding_1\"> Payee Name</div>\r\n          <ion-item class=\"form_field\">\r\n              <ion-input [(ngModel)]=\"ddpo.payeeName\" type=\"text\"></ion-input>\r\n            </ion-item>\r\n\r\n            <div class=\"label_text label_padding_1\"> DD Amount</div>\r\n          <ion-item class=\"form_field\">\r\n              <ion-input [(ngModel)]=\"ddpo.ddAmount\" type=\"numer\" (ionChange)=\"updateCommission()\"></ion-input>\r\n            </ion-item>\r\n\r\n            <div *ngIf=\"ddpo.ddAmount>0\" class=\"commisionBlock\">\r\n              <div class=\"eachBlock bottomBorder\">\r\n                <div >Commission</div><div class=\"commisionAmt\">&#8377;{{commissionAmount}}</div>\r\n              </div>\r\n              <div class=\"eachBlock\">\r\n                <div>Total</div><div>&#8377;{{totalPay}}</div>\r\n              </div>\r\n            </div>\r\n\r\n            <div class=\"label_text label_padding_1\"> Payable At</div>\r\n          <ion-item class=\"form_field\">\r\n              <ion-input [(ngModel)]=\"ddpo.payebleAt\"></ion-input>\r\n            </ion-item>\r\n            <!-- <ion-radio-group class=\"form_field radios\" >\r\n                <ion-item>\r\n                    <ion-radio value=\"0\" class=\"radio_theme\" [(ngModal)]=\"fromBranch\"></ion-radio>\r\n                  <ion-label class=\"label_radio\">Pick up from branch</ion-label>\r\n                </ion-item>\r\n            \r\n                <ion-item>\r\n                    <ion-radio value=\"1\" class=\"radio_theme\" [(ngModal)]=\"fromBranch\"></ion-radio>\r\n                  <ion-label class=\"label_radio\" >Deliver</ion-label>\r\n                </ion-item>\r\n                </ion-radio-group> -->\r\n                <div class=\"label_text label_padding_1\"> Delivery</div>\r\n                <ion-radio-group [(ngModel)]=\"fromBranch\" class=\"form_field radios\" >\r\n                     <ion-item>\r\n                        <ion-radio value=\"0\" class=\"radio_theme\" ></ion-radio>\r\n                      <ion-label class=\"label_radio\">Pick up from branch</ion-label>\r\n                    </ion-item>\r\n                \r\n                    <ion-item>\r\n                        <ion-radio value=\"1\" class=\"radio_theme\" ></ion-radio>\r\n                      <ion-label class=\"label_radio\" >Deliver</ion-label>\r\n                    </ion-item>\r\n                </ion-radio-group>\r\n            <div class=\"label_text label_padding_1\"> Address 1</div>\r\n          <ion-item class=\"form_field\">\r\n              <ion-input [(ngModel)]=\"ddpo.address1\"></ion-input>\r\n            </ion-item>\r\n\r\n            <div class=\"label_text label_padding_1\"> Address 2</div>\r\n          <ion-item class=\"form_field\">\r\n              <ion-input [(ngModel)]=\"ddpo.address2\"></ion-input>\r\n            </ion-item>\r\n\r\n            <div class=\"label_text label_padding_1\"> PIN</div>\r\n          <ion-item class=\"form_field\">\r\n              <ion-input (ionFocus)=\"clearErr()\" [(ngModel)]=\"ddpo.pinCode\" maxlength=\"6\"></ion-input>\r\n            </ion-item>\r\n            <div class=\"error_msg\" [ngClass]=\"{'showError':error}\">\r\n                {{ error }}\r\n               </div>\r\n              <div class=\"button_block\">\r\n                  <ion-button class=\"button_theme\" expand=\"block\" (click)=\"createddpo()\"\r\n                  [disabled]=\"!ddpo.accountNumber ||!ddpo.payeeName || !ddpo.ddAmount || !ddpo.payebleAt || !ddpo.address1 || !ddpo.address2 || !ddpo.pinCode \">Submit</ion-button>\r\n              </div>\r\n      </div>\r\n    \r\n  </ion-content>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/success-modal/success-modal.component.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/success-modal/success-modal.component.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"parent_block\" (click)=\"dismiss()\">\n<div class=\"Success_modal\" >\n  <div class=\"center_block\">\n    <ion-icon  class=\"icon_block\" name=\"checkmark-circle-outline\"></ion-icon>\n    <div class=\"text_block\">  Your Request is Successfully submitted.</div>\n  </div>\n</div>\n</div>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/support-complaint/new-complaint/new-complaint.component.html":
/*!********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/support-complaint/new-complaint/new-complaint.component.html ***!
  \********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header >\n    <ion-toolbar class=\"header\">\n      <ion-buttons slot=\"start\">\n          <ion-button (click)=\"back()\">\n            <ion-icon name=\"chevron-back-outline\" ></ion-icon>\n          </ion-button>\n      </ion-buttons>\n      <ion-title>New Complaint</ion-title>\n    </ion-toolbar>\n  </ion-header>\n  <ion-content>\n      <div class=\"page_container\">\n        \n            <div class=\"label_text label_padding\"> Subject</div>\n            <ion-item class=\"form_field\">\n                <ion-select class=\"slect_box\" [interfaceOptions]=\"customActionSheetOptions\" interface=\"action-sheet\" placeholder=\"Select Subject\">\n                  <ion-select-option value=\"red\">Subject A</ion-select-option>\n                  <ion-select-option value=\"green\">Subject B</ion-select-option>\n                </ion-select>\n              </ion-item>\n              <div class=\"label_text label_padding\"> Type</div>\n            <ion-item class=\"form_field\">\n                <ion-select class=\"slect_box\" [interfaceOptions]=\"customActionSheetOptions\" interface=\"action-sheet\" placeholder=\"Select Type\">\n                  <ion-select-option value=\"red\">Type A</ion-select-option>\n                  <ion-select-option value=\"green\">Type B</ion-select-option>\n                </ion-select>\n              </ion-item>\n              <div class=\"label_text label_padding\"> INFORMATION</div>\n              <ion-textarea class=\"info\"></ion-textarea>\n              <div class=\"button_block\">\n                  <ion-button class=\"button_theme\" expand=\"block\" (click)=\"changeEmail()\">Submit</ion-button>\n              </div>\n      </div>\n    \n  </ion-content>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/support-complaint/support-complaint.component.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/support-complaint/support-complaint.component.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar class=\"header\">\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"back()\">\n        <ion-icon name=\"chevron-back-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>Support & Complaint</ion-title>\n    <!-- <ion-buttons slot=\"end\">\n      <ion-button (click)=\"add()\">\n        <ion-icon name=\"add\"></ion-icon>\n      </ion-button>\n    </ion-buttons> -->\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <div class=\"page_container\">\n      <div class=\"button_block\">\n          <ion-button class=\"button_theme\" expand=\"block\" (click)=\"openWindow(supportUrl)\" >Support</ion-button>\n      </div><br/><br/>\n      <div class=\"button_block\">\n          <ion-button class=\"button_theme\" expand=\"block\" (click)=\"openWindow(complaintUrl)\" >Complaint</ion-button>\n      </div>\n    <!-- <div class=\"complaint_block\">\n      <div class=\"label_text\">\n        Complaint 1 <br />\n        13142453536636\n      </div>\n      <div class=\"open\">\n        Open\n      </div>\n    </div>\n\n    <div class=\"complaint_block\">\n        <div class=\"label_text\">\n          Complaint 1 <br />\n          13142453536636\n        </div>\n        <div class=\"closed\">\n          Closed\n        </div>\n      </div>\n\n      <div class=\"complaint_block\">\n          <div class=\"label_text\">\n            Complaint 1 <br />\n            13142453536636\n          </div>\n          <div class=\"open\">\n            Open\n          </div>\n        </div> -->\n  </div>\n\n</ion-content>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/verify-account/verify-account.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/verify-account/verify-account.component.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header >\r\n    <ion-toolbar class=\"header\">\r\n      <ion-buttons slot=\"start\">\r\n          <ion-button (click)=\"back()\">\r\n            <ion-icon name=\"chevron-back-outline\"></ion-icon>\r\n          </ion-button>\r\n      </ion-buttons>\r\n      <ion-title>Verify Account!</ion-title>\r\n     \r\n    </ion-toolbar>\r\n  </ion-header>\r\n  <ion-content>\r\n      <div class=\"page_container\">\r\n        <div class=\"info_block\">\r\n          Verify your account by entering 4 digits code we sent to : {{mobileNu}}\r\n        </div>\r\n\r\n          <ion-item class=\"form_field\">\r\n              <ion-icon name=\"qr-code-outline\" slot=\"start\"  class=\"icons\"></ion-icon>\r\n              <ion-label position=\"floating\" class=\"label\" >Enter OTP</ion-label>\r\n              <ion-input type=\"password\" maxlength=\"6\" [(ngModel)]=\"OTP.otp\"></ion-input>\r\n            </ion-item>\r\n            <div class=\"error_msg\" [ngClass]=\"{'showError':error}\">\r\n              {{ error }}\r\n             </div>\r\n              <div class=\"button_block\">\r\n                  <ion-button class=\"button_theme\" expand=\"block\" (click)=\"verify()\" [disabled]=\"OTP.otp.length != 6\">Verify</ion-button>\r\n              </div>\r\n              <div class=\"not_recieved_otp_block\">\r\n                Didn't recieved code? <span class=\"resend_txt\" (click)=\"resendOTP()\"> Resend Code</span>\r\n              </div>\r\n      </div>\r\n    \r\n  </ion-content>");

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _register_register_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./register/register.component */ "./src/app/register/register.component.ts");
/* harmony import */ var _verify_account_verify_account_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./verify-account/verify-account.component */ "./src/app/verify-account/verify-account.component.ts");
/* harmony import */ var _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./dashboard/dashboard.component */ "./src/app/dashboard/dashboard.component.ts");
/* harmony import */ var _change_email_change_email_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./change-email/change-email.component */ "./src/app/change-email/change-email.component.ts");
/* harmony import */ var _pre_approved_offers_pre_approved_offers_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./pre-approved-offers/pre-approved-offers.component */ "./src/app/pre-approved-offers/pre-approved-offers.component.ts");
/* harmony import */ var _change_pan_change_pan_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./change-pan/change-pan.component */ "./src/app/change-pan/change-pan.component.ts");
/* harmony import */ var _request_dd_po_request_dd_po_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./request-dd-po/request-dd-po.component */ "./src/app/request-dd-po/request-dd-po.component.ts");
/* harmony import */ var _pm_schemes_pm_schemes_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./pm-schemes/pm-schemes.component */ "./src/app/pm-schemes/pm-schemes.component.ts");
/* harmony import */ var _support_complaint_support_complaint_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./support-complaint/support-complaint.component */ "./src/app/support-complaint/support-complaint.component.ts");
/* harmony import */ var _support_complaint_new_complaint_new_complaint_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./support-complaint/new-complaint/new-complaint.component */ "./src/app/support-complaint/new-complaint/new-complaint.component.ts");
/* harmony import */ var _my_requests_my_requests_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./my-requests/my-requests.component */ "./src/app/my-requests/my-requests.component.ts");















const routes = [
    {
        path: '',
        component: _register_register_component__WEBPACK_IMPORTED_MODULE_4__["RegisterComponent"],
        pathMatch: 'full'
    }, {
        path: 'login',
        component: _login_login_component__WEBPACK_IMPORTED_MODULE_3__["LoginComponent"],
        pathMatch: 'full'
    }, {
        path: 'register',
        component: _register_register_component__WEBPACK_IMPORTED_MODULE_4__["RegisterComponent"],
        pathMatch: 'full'
    }, {
        path: 'verifyAccount',
        component: _verify_account_verify_account_component__WEBPACK_IMPORTED_MODULE_5__["VerifyAccountComponent"],
        pathMatch: 'full'
    }, {
        path: 'dashboard',
        component: _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_6__["DashboardComponent"],
        pathMatch: 'full'
    }, {
        path: 'changeEmail',
        component: _change_email_change_email_component__WEBPACK_IMPORTED_MODULE_7__["ChangeEmailComponent"],
        pathMatch: 'full'
    }, {
        path: 'preApprovedOffers',
        component: _pre_approved_offers_pre_approved_offers_component__WEBPACK_IMPORTED_MODULE_8__["PreApprovedOffersComponent"],
        pathMatch: 'full'
    }, {
        path: 'requestDdPo',
        component: _request_dd_po_request_dd_po_component__WEBPACK_IMPORTED_MODULE_10__["RequestDdPoComponent"],
        pathMatch: 'full'
    }, {
        path: 'changePan',
        component: _change_pan_change_pan_component__WEBPACK_IMPORTED_MODULE_9__["ChangePanComponent"],
        pathMatch: 'full'
    }, {
        path: 'pmSchemes',
        component: _pm_schemes_pm_schemes_component__WEBPACK_IMPORTED_MODULE_11__["PmSchemesComponent"],
        pathMatch: 'full'
    }, {
        path: 'supportComplaint',
        component: _support_complaint_support_complaint_component__WEBPACK_IMPORTED_MODULE_12__["SupportComplaintComponent"],
        pathMatch: 'full'
    },
    {
        path: 'newComplaint',
        component: _support_complaint_new_complaint_new_complaint_component__WEBPACK_IMPORTED_MODULE_13__["NewComplaintComponent"],
        pathMatch: 'full'
    },
    {
        path: 'myRequests',
        component: _my_requests_my_requests_component__WEBPACK_IMPORTED_MODULE_14__["MyRequestsComponent"],
        pathMatch: 'full'
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-menu ion-content {\n  --background: var(--ion-item-background, var(--ion-background-color, #fff));\n}\n\nion-menu.md ion-content {\n  --padding-start: 8px;\n  --padding-end: 8px;\n  --padding-top: 20px;\n  --padding-bottom: 20px;\n}\n\nion-menu.md ion-list {\n  padding: 0 0 20px 0;\n}\n\nion-menu.md ion-note {\n  margin-bottom: 30px;\n}\n\nion-menu.md ion-list-header,\nion-menu.md ion-note {\n  padding-left: 10px;\n}\n\nion-menu.md ion-list#inbox-list {\n  border-bottom: 1px solid var(--ion-color-step-150, #d7d8da);\n}\n\nion-menu.md ion-list#inbox-list ion-list-header {\n  font-size: 22px;\n  font-weight: 600;\n  min-height: 20px;\n}\n\nion-menu.md ion-list#labels-list ion-list-header {\n  font-size: 16px;\n  margin-bottom: 18px;\n  color: #757575;\n  min-height: 26px;\n}\n\nion-menu.md ion-item {\n  --padding-start: 10px;\n  --padding-end: 10px;\n  border-radius: 4px;\n}\n\nion-menu.md ion-item.selected {\n  --background: rgba(var(--ion-color-primary-rgb), 0.14);\n}\n\nion-menu.md ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.md ion-item ion-icon {\n  color: #616e7e;\n}\n\nion-menu.md ion-item ion-label {\n  font-weight: 500;\n}\n\nion-menu.ios ion-content {\n  --padding-bottom: 20px;\n}\n\nion-menu.ios ion-list {\n  padding: 20px 0 0 0;\n}\n\nion-menu.ios ion-note {\n  line-height: 24px;\n  margin-bottom: 20px;\n}\n\nion-menu.ios ion-item {\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --min-height: 50px;\n}\n\nion-menu.ios ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.ios ion-item ion-icon {\n  font-size: 24px;\n  color: #73849a;\n}\n\nion-menu.ios ion-list#labels-list ion-list-header {\n  margin-bottom: 8px;\n}\n\nion-menu.ios ion-list-header,\nion-menu.ios ion-note {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n\nion-menu.ios ion-note {\n  margin-bottom: 8px;\n}\n\nion-note {\n  display: inline-block;\n  font-size: 16px;\n  color: #1a7cbc;\n}\n\nion-item.selected {\n  --color: var(--ion-color-primary);\n}\n\n.profile {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-flow: column;\n}\n\n.profile .image_profile {\n  font-size: 50px;\n  color: #1a7cbc;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsMkVBQUE7QUFDRjs7QUFFQTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxtQkFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7QUFDRjs7QUFFQTs7RUFFRSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsMkRBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUVBLGdCQUFBO0FBQUY7O0FBR0E7RUFDRSxlQUFBO0VBRUEsbUJBQUE7RUFFQSxjQUFBO0VBRUEsZ0JBQUE7QUFIRjs7QUFNQTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUhGOztBQU1BO0VBQ0Usc0RBQUE7QUFIRjs7QUFNQTtFQUNFLCtCQUFBO0FBSEY7O0FBTUE7RUFDRSxjQUFBO0FBSEY7O0FBTUE7RUFDRSxnQkFBQTtBQUhGOztBQU1BO0VBQ0Usc0JBQUE7QUFIRjs7QUFNQTtFQUNFLG1CQUFBO0FBSEY7O0FBTUE7RUFDRSxpQkFBQTtFQUNBLG1CQUFBO0FBSEY7O0FBTUE7RUFDRSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFIRjs7QUFNQTtFQUNFLCtCQUFBO0FBSEY7O0FBTUE7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQUhGOztBQU1BO0VBQ0Usa0JBQUE7QUFIRjs7QUFNQTs7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBSEY7O0FBTUE7RUFDRSxrQkFBQTtBQUhGOztBQU1BO0VBQ0UscUJBQUE7RUFDQSxlQUFBO0VBRUEsY0FBQTtBQUpGOztBQU9BO0VBQ0UsaUNBQUE7QUFKRjs7QUFNQTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsaUJBQUE7QUFIRjs7QUFLRTtFQUNJLGVBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUFITiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1tZW51IGlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24taXRlbS1iYWNrZ3JvdW5kLCB2YXIoLS1pb24tYmFja2dyb3VuZC1jb2xvciwgI2ZmZikpO1xufVxuXG5pb24tbWVudS5tZCBpb24tY29udGVudCB7XG4gIC0tcGFkZGluZy1zdGFydDogOHB4O1xuICAtLXBhZGRpbmctZW5kOiA4cHg7XG4gIC0tcGFkZGluZy10b3A6IDIwcHg7XG4gIC0tcGFkZGluZy1ib3R0b206IDIwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0IHtcbiAgcGFkZGluZzowIDAgMjBweCAwO1xufVxuXG5pb24tbWVudS5tZCBpb24tbm90ZSB7XG4gIG1hcmdpbi1ib3R0b206IDMwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0LWhlYWRlcixcbmlvbi1tZW51Lm1kIGlvbi1ub3RlIHtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24tbGlzdCNpbmJveC1saXN0IHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zdGVwLTE1MCwgI2Q3ZDhkYSk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0I2luYm94LWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgZm9udC1zaXplOiAyMnB4O1xuICBmb250LXdlaWdodDogNjAwO1xuXG4gIG1pbi1oZWlnaHQ6IDIwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0I2xhYmVscy1saXN0IGlvbi1saXN0LWhlYWRlciB7XG4gIGZvbnQtc2l6ZTogMTZweDtcblxuICBtYXJnaW4tYm90dG9tOiAxOHB4O1xuXG4gIGNvbG9yOiAjNzU3NTc1O1xuXG4gIG1pbi1oZWlnaHQ6IDI2cHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xuICAtLXBhZGRpbmctZW5kOiAxMHB4O1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtLnNlbGVjdGVkIHtcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXJnYiksIDAuMTQpO1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbS5zZWxlY3RlZCBpb24taWNvbiB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIGlvbi1pY29uIHtcbiAgY29sb3I6ICM2MTZlN2U7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIGlvbi1sYWJlbCB7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tY29udGVudCB7XG4gIC0tcGFkZGluZy1ib3R0b206IDIwcHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbGlzdCB7XG4gIHBhZGRpbmc6IDIwcHggMCAwIDA7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIGxpbmUtaGVpZ2h0OiAyNHB4O1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWl0ZW0ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDE2cHg7XG4gIC0tcGFkZGluZy1lbmQ6IDE2cHg7XG4gIC0tbWluLWhlaWdodDogNTBweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1pY29uIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyNHB4O1xuICBjb2xvcjogIzczODQ5YTtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1saXN0I2xhYmVscy1saXN0IGlvbi1saXN0LWhlYWRlciB7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1saXN0LWhlYWRlcixcbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIHBhZGRpbmctbGVmdDogMTZweDtcbiAgcGFkZGluZy1yaWdodDogMTZweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1ub3RlIHtcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xufVxuXG5pb24tbm90ZSB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgZm9udC1zaXplOiAxNnB4O1xuXG4gIGNvbG9yOiAjMWE3Y2JjO1xufVxuXG5pb24taXRlbS5zZWxlY3RlZCB7XG4gIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cbi5wcm9maWxle1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgZmxleC1mbG93OiBjb2x1bW47XG5cbiAgLmltYWdlX3Byb2ZpbGV7XG4gICAgICBmb250LXNpemU6IDUwcHg7XG4gICAgICBjb2xvcjogIzFhN2NiYztcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgfVxuICB9Il19 */");

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./common.service */ "./src/app/common.service.ts");
/* harmony import */ var _common_service_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./common/service/storage.service */ "./src/app/common/service/storage.service.ts");







let AppComponent = class AppComponent {
    constructor(platform, splashScreen, statusBar, commonSer, storgeSer, navCtrl) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.commonSer = commonSer;
        this.storgeSer = storgeSer;
        this.navCtrl = navCtrl;
        this.selectedIndex = 0;
        this.appPages = [
            {
                title: 'Login',
                url: '',
                icon: 'mail'
            },
            {
                title: 'Register',
                url: 'register',
                icon: 'paper-plane'
            },
            {
                title: 'verifyAccount',
                url: 'verifyAccount',
                icon: 'heart'
            },
            {
                title: 'dashboard',
                url: 'dashboard',
                icon: 'archive'
            },
            {
                title: 'changeEmail',
                url: 'changeEmail',
                icon: 'trash'
            },
            {
                title: 'preApprovedOffers',
                url: 'preApprovedOffers',
                icon: 'warning'
            }
        ];
        this.labels = ['Family', 'Friends', 'Notes', 'Work', 'Travel', 'Reminders'];
        this.initializeApp();
    }
    initializeApp() {
        this.platform.ready().then(() => {
            this.statusBar.styleDefault();
            this.splashScreen.hide();
            document.addEventListener('backbutton', (e) => {
                console.log('disable back button');
                return false;
            }, true);
        });
    }
    ngOnInit() {
        const path = window.location.pathname.split('folder/')[1];
        if (path !== undefined) {
            this.selectedIndex = this.appPages.findIndex(page => page.title.toLowerCase() === path.toLowerCase());
        }
        this.commonSer.spinnerUpdated.subscribe((state) => {
            console.log('in compspinnerState', state);
            this.spinnerState = state;
        });
        let custId = this.storgeSer.getItem('AccountVerified');
        if (custId) {
            this.navCtrl.navigateRoot('login');
        }
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
    { type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"] },
    { type: _common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"] },
    { type: _common_service_storage_service__WEBPACK_IMPORTED_MODULE_6__["StorageService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] }
];
AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-root',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")).default]
    })
], AppComponent);



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _app_common_service_interceptor_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../app/common/service/interceptor.service */ "./src/app/common/service/interceptor.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _pre_approved_offers_pre_approved_offers_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./pre-approved-offers/pre-approved-offers.component */ "./src/app/pre-approved-offers/pre-approved-offers.component.ts");
/* harmony import */ var _register_register_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./register/register.component */ "./src/app/register/register.component.ts");
/* harmony import */ var _verify_account_verify_account_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./verify-account/verify-account.component */ "./src/app/verify-account/verify-account.component.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _pm_schemes_pm_schemes_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./pm-schemes/pm-schemes.component */ "./src/app/pm-schemes/pm-schemes.component.ts");
/* harmony import */ var _change_email_change_email_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./change-email/change-email.component */ "./src/app/change-email/change-email.component.ts");
/* harmony import */ var _ionic_native_fingerprint_aio_ngx__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @ionic-native/fingerprint-aio/ngx */ "./node_modules/@ionic-native/fingerprint-aio/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _support_complaint_support_complaint_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./support-complaint/support-complaint.component */ "./src/app/support-complaint/support-complaint.component.ts");
/* harmony import */ var _request_dd_po_request_dd_po_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./request-dd-po/request-dd-po.component */ "./src/app/request-dd-po/request-dd-po.component.ts");
/* harmony import */ var _change_pan_change_pan_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./change-pan/change-pan.component */ "./src/app/change-pan/change-pan.component.ts");
/* harmony import */ var _support_complaint_new_complaint_new_complaint_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./support-complaint/new-complaint/new-complaint.component */ "./src/app/support-complaint/new-complaint/new-complaint.component.ts");
/* harmony import */ var _success_modal_success_modal_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./success-modal/success-modal.component */ "./src/app/success-modal/success-modal.component.ts");
/* harmony import */ var _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./dashboard/dashboard.component */ "./src/app/dashboard/dashboard.component.ts");
/* harmony import */ var _my_requests_my_requests_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./my-requests/my-requests.component */ "./src/app/my-requests/my-requests.component.ts");



























//https://github.com/NiklasMerz/cordova-plugin-fingerprint-aio
let AppModule = class AppModule {
};
AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"], _pre_approved_offers_pre_approved_offers_component__WEBPACK_IMPORTED_MODULE_12__["PreApprovedOffersComponent"],
            _register_register_component__WEBPACK_IMPORTED_MODULE_13__["RegisterComponent"], _verify_account_verify_account_component__WEBPACK_IMPORTED_MODULE_14__["VerifyAccountComponent"], _change_email_change_email_component__WEBPACK_IMPORTED_MODULE_17__["ChangeEmailComponent"],
            _pm_schemes_pm_schemes_component__WEBPACK_IMPORTED_MODULE_16__["PmSchemesComponent"],
            _support_complaint_support_complaint_component__WEBPACK_IMPORTED_MODULE_19__["SupportComplaintComponent"],
            _my_requests_my_requests_component__WEBPACK_IMPORTED_MODULE_25__["MyRequestsComponent"],
            _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_24__["DashboardComponent"],
            _request_dd_po_request_dd_po_component__WEBPACK_IMPORTED_MODULE_20__["RequestDdPoComponent"],
            _change_pan_change_pan_component__WEBPACK_IMPORTED_MODULE_21__["ChangePanComponent"],
            _success_modal_success_modal_component__WEBPACK_IMPORTED_MODULE_23__["SuccessModalComponent"],
            _support_complaint_new_complaint_new_complaint_component__WEBPACK_IMPORTED_MODULE_22__["NewComplaintComponent"],
            _login_login_component__WEBPACK_IMPORTED_MODULE_15__["LoginComponent"]],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_11__["HttpClientModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_10__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"].forRoot({ hardwareBackButton: false, mode: 'md' }),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_9__["AppRoutingModule"]
        ],
        providers: [
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__["StatusBar"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_6__["SplashScreen"],
            _ionic_native_fingerprint_aio_ngx__WEBPACK_IMPORTED_MODULE_18__["FingerprintAIO"],
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicRouteStrategy"] },
            {
                provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_11__["HTTP_INTERCEPTORS"],
                useClass: _app_common_service_interceptor_service__WEBPACK_IMPORTED_MODULE_4__["HttpInterceptorService"],
                multi: true
            },
        ],
        schemas: [
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["CUSTOM_ELEMENTS_SCHEMA"],
            _angular_core__WEBPACK_IMPORTED_MODULE_1__["NO_ERRORS_SCHEMA"]
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "./src/app/change-email/change-email.component.scss":
/*!**********************************************************!*\
  !*** ./src/app/change-email/change-email.component.scss ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".button_block {\n  padding-top: 200px;\n}\n\n.inst_block {\n  color: #123b67;\n  padding-top: 30px;\n  font-weight: 500;\n}\n\n.inst_block .title_block {\n  font-size: 18px;\n}\n\n.inst_block .inst {\n  padding: 10px 0 0 0;\n  display: flex;\n}\n\n.inst_block .inst .star {\n  padding-right: 5px;\n}\n\n.cust_id {\n  color: #123b67;\n  font-weight: 600;\n  padding-bottom: 14px;\n  text-align: left;\n  border-bottom: 1px solid #123b67;\n  margin-bottom: 4px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2hhbmdlLWVtYWlsL2NoYW5nZS1lbWFpbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFBO0FBQ0o7O0FBRUE7RUFDSSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQUNKOztBQUFJO0VBQ0ksZUFBQTtBQUVSOztBQUFJO0VBQ0ksbUJBQUE7RUFDQSxhQUFBO0FBRVI7O0FBRFE7RUFDSSxrQkFBQTtBQUdaOztBQUNBO0VBQ0ksY0FBQTtFQUNBLGdCQUFBO0VBQ0Esb0JBQUE7RUFDQSxnQkFBQTtFQUNBLGdDQUFBO0VBQ0Esa0JBQUE7QUFFSiIsImZpbGUiOiJzcmMvYXBwL2NoYW5nZS1lbWFpbC9jaGFuZ2UtZW1haWwuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYnV0dG9uX2Jsb2Nre1xyXG4gICAgcGFkZGluZy10b3A6IDIwMHB4O1xyXG59XHJcblxyXG4uaW5zdF9ibG9ja3tcclxuICAgIGNvbG9yOiMxMjNiNjc7XHJcbiAgICBwYWRkaW5nLXRvcDogMzBweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAudGl0bGVfYmxvY2t7XHJcbiAgICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgfVxyXG4gICAgLmluc3R7XHJcbiAgICAgICAgcGFkZGluZzoxMHB4IDAgMCAwO1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgLnN0YXJ7XHJcbiAgICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IDVweDs7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbi5jdXN0X2lke1xyXG4gICAgY29sb3I6ICMxMjNiNjc7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgcGFkZGluZy1ib3R0b206IDE0cHg7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICMxMjNiNjc7XHJcbiAgICBtYXJnaW4tYm90dG9tOiA0cHg7XHJcbn0iXX0= */");

/***/ }),

/***/ "./src/app/change-email/change-email.component.ts":
/*!********************************************************!*\
  !*** ./src/app/change-email/change-email.component.ts ***!
  \********************************************************/
/*! exports provided: ChangeEmailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChangeEmailComponent", function() { return ChangeEmailComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _success_modal_success_modal_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../success-modal/success-modal.component */ "./src/app/success-modal/success-modal.component.ts");
/* harmony import */ var _email_update_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../email-update.service */ "./src/app/email-update.service.ts");
/* harmony import */ var _common_constants_regExp_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common/constants/regExp.constants */ "./src/app/common/constants/regExp.constants.ts");
/* harmony import */ var _common_constants_apiErrorMessages_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../common/constants/apiErrorMessages.constants */ "./src/app/common/constants/apiErrorMessages.constants.ts");
/* harmony import */ var _common_service_storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../common/service/storage.service */ "./src/app/common/service/storage.service.ts");









let ChangeEmailComponent = class ChangeEmailComponent {
    // Email: FormGroup;
    constructor(navController, modalController, storageSer, emailUpdateService) {
        this.navController = navController;
        this.modalController = modalController;
        this.storageSer = storageSer;
        this.emailUpdateService = emailUpdateService;
        this.changeEml = {
            email: "",
            customerId: localStorage.getItem('customerId'),
            customerName: "",
            branchId: ""
        };
        this.error = "";
    }
    ngOnInit() { }
    changeEmail() {
        console.log('changeEmail');
        if (this.validateForm()) {
            let userDetails = JSON.parse(this.storageSer.getItem('registerDetails'));
            this.changeEml.customerName = userDetails.customerName;
            this.changeEml.customerId = userDetails.customerId;
            this.changeEml.branchId = userDetails.branchId;
            this.emailUpdateService.changeEmail(this.changeEml)
                .subscribe(data => {
                console.log("data", data);
                //     if(data.data.customerId){
                //       localStorage.setItem("customerId",data.data.customerId);
                //       this.navController.navigateForward('verifyAccount');
                //     }
                // });
                this.presentActionSheet();
            });
        }
    }
    clearErr() {
        this.error = "";
    }
    validateForm() {
        if (!_common_constants_regExp_constants__WEBPACK_IMPORTED_MODULE_5__["REGEX_PATTERNS"].email.test(this.changeEml.email)) {
            this.error = _common_constants_apiErrorMessages_constants__WEBPACK_IMPORTED_MODULE_6__["APP_ERROR_MESSAGES"].invalidEmail;
            return false;
        }
        return true;
        ;
    }
    back() {
        this.navController.back();
    }
    presentActionSheet() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _success_modal_success_modal_component__WEBPACK_IMPORTED_MODULE_3__["SuccessModalComponent"],
                cssClass: 'successModal',
                backdropDismiss: true,
            });
            modal.onDidDismiss().then(data => {
                console.log('dismissed', data);
                this.navController.pop();
            });
            setTimeout(() => { if (modal) {
                modal.dismiss();
            } }, 3000);
            return yield modal.present();
        });
    }
};
ChangeEmailComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _common_service_storage_service__WEBPACK_IMPORTED_MODULE_7__["StorageService"] },
    { type: _email_update_service__WEBPACK_IMPORTED_MODULE_4__["EmailUpdateService"] }
];
ChangeEmailComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-change-email',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./change-email.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/change-email/change-email.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./change-email.component.scss */ "./src/app/change-email/change-email.component.scss")).default]
    })
], ChangeEmailComponent);



/***/ }),

/***/ "./src/app/change-pan/change-pan.component.scss":
/*!******************************************************!*\
  !*** ./src/app/change-pan/change-pan.component.scss ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".button_block {\n  padding-top: 150px;\n}\n\n.cust_id {\n  color: #123b67;\n  font-weight: 600;\n  padding-bottom: 14px;\n  text-align: left;\n  border-bottom: 1px solid #123b67;\n  margin-bottom: 4px;\n}\n\n.upload_block {\n  width: 100%;\n  height: 150px;\n  align-items: center;\n  display: flex;\n  box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 1px 5px 0px;\n  justify-content: center;\n  margin-top: 10px;\n}\n\n.upload_block .upload_icon {\n  color: #5a5a62;\n  font-size: 50px;\n  opacity: 0.5;\n}\n\n.accept_text {\n  padding: 10px 0;\n  display: flex;\n  align-items: center;\n}\n\n.accept_text .label {\n  color: #123b67;\n  padding-left: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2hhbmdlLXBhbi9jaGFuZ2UtcGFuLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksa0JBQUE7QUFBSjs7QUFHQTtFQUNJLGNBQUE7RUFDQSxnQkFBQTtFQUNBLG9CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQ0FBQTtFQUNBLGtCQUFBO0FBQUo7O0FBR0E7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLHlIQUFBO0VBQ0EsdUJBQUE7RUFDQSxnQkFBQTtBQUFKOztBQUNJO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDSixZQUFBO0FBQ0o7O0FBR0E7RUFDSSxlQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBQUo7O0FBQ0k7RUFDSSxjQUFBO0VBQ0Esa0JBQUE7QUFDUiIsImZpbGUiOiJzcmMvYXBwL2NoYW5nZS1wYW4vY2hhbmdlLXBhbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4uYnV0dG9uX2Jsb2Nre1xyXG4gICAgcGFkZGluZy10b3A6IDE1MHB4O1xyXG59XHJcblxyXG4uY3VzdF9pZHtcclxuICAgIGNvbG9yOiAjMTIzYjY3O1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxNHB4O1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMTIzYjY3O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNHB4O1xyXG59XHJcblxyXG4udXBsb2FkX2Jsb2Nre1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDE1MHB4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBib3gtc2hhZG93OiByZ2JhKDAsIDAsIDAsIDAuMikgMHB4IDNweCAxcHggLTJweCwgcmdiYSgwLCAwLCAwLCAwLjE0KSAwcHggMnB4IDJweCAwcHgsIHJnYmEoMCwgMCwgMCwgMC4xMikgMHB4IDFweCA1cHggMHB4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgLnVwbG9hZF9pY29ue1xyXG4gICAgICAgIGNvbG9yOiAjNWE1YTYyO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogNTBweDtcclxuICAgIG9wYWNpdHk6IDAuNTtcclxuICAgIH1cclxufVxyXG5cclxuLmFjY2VwdF90ZXh0e1xyXG4gICAgcGFkZGluZzoxMHB4IDA7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIC5sYWJlbHtcclxuICAgICAgICBjb2xvcjojMTIzYjY3O1xyXG4gICAgICAgIHBhZGRpbmctbGVmdDogMTBweDtcclxuICAgIH1cclxufSJdfQ== */");

/***/ }),

/***/ "./src/app/change-pan/change-pan.component.ts":
/*!****************************************************!*\
  !*** ./src/app/change-pan/change-pan.component.ts ***!
  \****************************************************/
/*! exports provided: ChangePanComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChangePanComponent", function() { return ChangePanComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _success_modal_success_modal_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../success-modal/success-modal.component */ "./src/app/success-modal/success-modal.component.ts");
/* harmony import */ var _pan_update_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../pan-update.service */ "./src/app/pan-update.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _common_service_storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../common/service/storage.service */ "./src/app/common/service/storage.service.ts");








let ChangePanComponent = class ChangePanComponent {
    constructor(navController, modalController, formBuilder, storageSer, sanitizer, panUpdateService) {
        this.navController = navController;
        this.modalController = modalController;
        this.formBuilder = formBuilder;
        this.storageSer = storageSer;
        this.sanitizer = sanitizer;
        this.panUpdateService = panUpdateService;
        this.pan = {
            PANNumber: '',
            PANImg: '',
            customerId: localStorage.getItem('customerId'),
            branchId: '',
            customerName: ''
        };
        this.acceptTerms = false;
        this.loading = false;
        this.createForm();
    }
    ngOnInit() { }
    createForm() {
        this.form = this.formBuilder.group({
            name: null,
            avatar: null
        });
    }
    changePan() {
        let userDetails = JSON.parse(this.storageSer.getItem('registerDetails'));
        this.pan.customerName = userDetails.customerName;
        this.pan.customerId = userDetails.customerId;
        this.pan.branchId = userDetails.branchId;
        let request = new FormData();
        request.append('branchId', userDetails.branchId);
        request.append('PANImg', this.form.get('avatar').value);
        request.append('customerId', userDetails.customerId);
        request.append('customerName', userDetails.customerName);
        request.append('PANNumber', this.pan.PANNumber);
        this.panUpdateService.changePan(request)
            .subscribe(data => {
            console.log("data", data);
            //     if(data.data.customerId){
            //       localStorage.setItem("customerId",data.data.customerId);
            //       this.navController.navigateForward('verifyAccount');
            //     }
            // });
            this.presentActionSheet();
        });
    }
    back() {
        this.navController.back();
    }
    presentActionSheet() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _success_modal_success_modal_component__WEBPACK_IMPORTED_MODULE_3__["SuccessModalComponent"],
                cssClass: 'successModal',
                backdropDismiss: true,
            });
            modal.onDidDismiss().then(data => {
                console.log('dismissed', data);
                this.navController.pop();
            });
            setTimeout(() => { if (modal) {
                modal.dismiss();
            } }, 3000);
            return yield modal.present();
        });
    }
    changeCheckbox(event) {
        console.log(this.acceptTerms, event);
        this.acceptTerms = event.detail.checked;
    }
    fileChange(event) {
        if (event.target.files && event.target.files[0]) {
            let reader = new FileReader();
            reader.onload = (event) => {
                this.pan.PANImg = event.target.result;
                this.imageFile = this.sanitizer.bypassSecurityTrustUrl(event.target.result);
            };
            reader.readAsDataURL(event.target.files[0]); // to trigger onload
        }
        let fileList = event.target.files;
        let file = fileList[0];
        console.log(file);
        if (event.target.files.length > 0) {
            this.selectedFile = event.target.files[0];
            this.form.get('avatar').setValue(this.selectedFile);
        }
    }
};
ChangePanComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"] },
    { type: _common_service_storage_service__WEBPACK_IMPORTED_MODULE_7__["StorageService"] },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"] },
    { type: _pan_update_service__WEBPACK_IMPORTED_MODULE_4__["PanUpdateService"] }
];
ChangePanComponent.propDecorators = {
    fileInput: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"], args: ['fileInput',] }]
};
ChangePanComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-change-pan',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./change-pan.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/change-pan/change-pan.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./change-pan.component.scss */ "./src/app/change-pan/change-pan.component.scss")).default]
    })
], ChangePanComponent);



/***/ }),

/***/ "./src/app/common.service.ts":
/*!***********************************!*\
  !*** ./src/app/common.service.ts ***!
  \***********************************/
/*! exports provided: CommonService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CommonService", function() { return CommonService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");



let CommonService = class CommonService {
    constructor() {
        this.spinner = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        this.spinnerUpdated = this.spinner.asObservable();
    }
    updateState(show) {
        this.state = show;
        this.spinner.next(this.state);
    }
};
CommonService.ctorParameters = () => [];
CommonService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], CommonService);



/***/ }),

/***/ "./src/app/common/constants/apiErrorMessages.constants.ts":
/*!****************************************************************!*\
  !*** ./src/app/common/constants/apiErrorMessages.constants.ts ***!
  \****************************************************************/
/*! exports provided: APP_ERROR_MESSAGES */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "APP_ERROR_MESSAGES", function() { return APP_ERROR_MESSAGES; });
const APP_ERROR_MESSAGES = {
    "enterMobileNo": "Please enter mobile number ",
    "invalidMobileNo": "Please enter valid mobile number.",
    "enterAccNo": "Please enter account number",
    "invalidAccNo": "Please enter valid account number.",
    "invalidEmail": "Please enter valid email.",
    "invalidPin": "Please enter valid PIN."
};


/***/ }),

/***/ "./src/app/common/constants/regExp.constants.ts":
/*!******************************************************!*\
  !*** ./src/app/common/constants/regExp.constants.ts ***!
  \******************************************************/
/*! exports provided: REGEX_PATTERNS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "REGEX_PATTERNS", function() { return REGEX_PATTERNS; });
const REGEX_PATTERNS = {
    phone: /^((\\+[0-9]{0,2}-?)|0)?[0-9]{10}$/,
    password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~])[A-Za-z\d `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]{8,}$/,
    email: /\S+@\S+\.\S+/,
    number: /^[0-9]*(\\.[0-9]{1,})?$/,
    accountNo: /^([0-9]{14})|([0-9]{2}-[0-9]{3}-[0-9]{6})$/,
    currency: /^\$?([0-9]{1,3},([0-9]{3},)*[0-9]{3}|[0-9]+)(.[0-9][0-9])?$/,
    pinCode: /^[1-9][0-9]{5}$/,
};


/***/ }),

/***/ "./src/app/common/errHandler/errorhandler.ts":
/*!***************************************************!*\
  !*** ./src/app/common/errHandler/errorhandler.ts ***!
  \***************************************************/
/*! exports provided: MyErrorStateMatcher */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyErrorStateMatcher", function() { return MyErrorStateMatcher; });
/** Error when invalid control is dirty, touched, or submitted. */
class MyErrorStateMatcher {
    isErrorState(control, form) {
        const isSubmitted = form && form.submitted;
        return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
    }
}


/***/ }),

/***/ "./src/app/common/service/interceptor.service.ts":
/*!*******************************************************!*\
  !*** ./src/app/common/service/interceptor.service.ts ***!
  \*******************************************************/
/*! exports provided: HttpInterceptorService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HttpInterceptorService", function() { return HttpInterceptorService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./storage.service */ "./src/app/common/service/storage.service.ts");
/* harmony import */ var src_app_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/common.service */ "./src/app/common.service.ts");




// import { ApiURLs } from '../constants/apiUrls.constants';
// import { ROUTE_MANAGER } from '../constants/routeManager.constant';


let HttpInterceptorService = class HttpInterceptorService {
    constructor(storageService, commonService) {
        this.storageService = storageService;
        this.commonService = commonService;
    }
    intercept(req, next) {
        //TODO: loading screen start action
        let headers = req.headers;
        let requestUrl = (req.url).split('/');
        // let apiObject;
        // apiObject = ApiURLs[requestUrl];
        let authtoken = this.storageService.getItem('authtoken');
        let noAuthTokenURLs = ['register'];
        console.log('requestUrl', requestUrl, noAuthTokenURLs.indexOf(requestUrl[requestUrl.length - 1]) == -1);
        if (authtoken && noAuthTokenURLs.indexOf(requestUrl[requestUrl.length - 1]) == -1) {
            req = req.clone({
                setHeaders: {
                    authtoken: authtoken,
                    'Content-Type': 'application/json'
                }
            });
            // return next.handle(req);
        }
        // else{
        //   req = req.clone({
        //     setHeaders: {'Content-Type':'application/json'
        //   }
        // });
        // }
        // const authReq = req.clone({ headers,url: environment.baseUrl + apiObject.url });
        console.log('request...');
        this.commonService.updateState(true);
        return next.handle(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])((event) => {
            //TODO: loading screen stop action or data validity logic/action
            setTimeout(() => { this.commonService.updateState(false); }, 2500);
            return event;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])((error) => {
            this.commonService.updateState(false);
            if (error.error instanceof ErrorEvent) {
                console.log(error.error.message);
            }
            if (error.status == 403) {
                //TODO: logout or session expiry logic/action;
                // this.storageService.removeItem('accessToken');
                // this.router.navigate([ROUTE_MANAGER.defaultPreloginRoute]);
            }
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["throwError"])(error);
        }));
    }
};
HttpInterceptorService.ctorParameters = () => [
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"] },
    { type: src_app_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"] }
];
HttpInterceptorService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
], HttpInterceptorService);



/***/ }),

/***/ "./src/app/common/service/storage.service.ts":
/*!***************************************************!*\
  !*** ./src/app/common/service/storage.service.ts ***!
  \***************************************************/
/*! exports provided: StorageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StorageService", function() { return StorageService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let StorageService = class StorageService {
    setItem(key, value) {
        return new Promise((resolve, reject) => {
            localStorage.setItem(key, value);
            resolve();
        });
    }
    getItem(key) {
        return localStorage.getItem(key);
    }
    removeItem(key) {
        localStorage.removeItem(key);
    }
    removeAll() {
        localStorage.clear();
    }
};
StorageService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], StorageService);



/***/ }),

/***/ "./src/app/constant/constants.ts":
/*!***************************************!*\
  !*** ./src/app/constant/constants.ts ***!
  \***************************************/
/*! exports provided: API_ENDPOINT */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "API_ENDPOINT", function() { return API_ENDPOINT; });
const API_ENDPOINT = {
    local: "http://localhost:3002/",
    development: "http://54.144.164.12/bom/"
    // development:"https://125.17.241.116/"
};


/***/ }),

/***/ "./src/app/customer.service.ts":
/*!*************************************!*\
  !*** ./src/app/customer.service.ts ***!
  \*************************************/
/*! exports provided: CustomerService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerService", function() { return CustomerService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let CustomerService = class CustomerService {
    constructor() {
        this.customer = {};
    }
    setCustomer(data) {
        this.customer = data;
    }
    getCustomer() {
        return this.customer;
    }
    clearCustomer() {
        this.customer = {};
        return this.customer;
    }
};
CustomerService.ctorParameters = () => [];
CustomerService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], CustomerService);



/***/ }),

/***/ "./src/app/dashboard.service.ts":
/*!**************************************!*\
  !*** ./src/app/dashboard.service.ts ***!
  \**************************************/
/*! exports provided: DashboardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardService", function() { return DashboardService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_constant_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../app/constant/constants */ "./src/app/constant/constants.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _common_service_storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./common/service/storage.service */ "./src/app/common/service/storage.service.ts");





let DashboardService = class DashboardService {
    constructor(http, storageSer) {
        this.http = http;
        this.storageSer = storageSer;
        this.accounts = ['12223242424', '43535353535353'];
    }
    getAccounts() {
        let userDetails = JSON.parse(this.storageSer.getItem('registerDetails'));
        return this.http.get(_app_constant_constants__WEBPACK_IMPORTED_MODULE_2__["API_ENDPOINT"].development + 'accounts/' + userDetails.customerId);
    }
    getStoredAccounts() {
        return this.accounts;
    }
    setAccounts(accounts) {
        this.accounts = accounts;
    }
};
DashboardService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _common_service_storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"] }
];
DashboardService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], DashboardService);



/***/ }),

/***/ "./src/app/dashboard/dashboard.component.scss":
/*!****************************************************!*\
  !*** ./src/app/dashboard/dashboard.component.scss ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-slides {\n  height: 240px;\n  --bullet-background-active:#1a7cbc;\n  --bullet-background:#1a7cbc;\n  --scroll-bar-background:#1a7cbc;\n  margin-top: -30px;\n}\n\n.slide_image_block {\n  border-radius: 20px;\n}\n\n.slide_image {\n  width: 95%;\n  height: 180px;\n  border-radius: 10px;\n}\n\n.logout_icon {\n  color: #fff;\n}\n\n.options {\n  box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 1px 5px 0px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-flow: column;\n  height: 100px;\n  padding: 5px;\n}\n\n.options .ion-icon {\n  color: #1a7cbc;\n  padding: 10px;\n  font-size: 30px;\n}\n\n.label_block {\n  color: #123b67;\n  font-weight: 600;\n  padding-top: 10px;\n  font-size: 13px;\n  text-align: center;\n}\n\n.icon_overlay {\n  height: 50px;\n  width: 50px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border-radius: 10px;\n}\n\n.options_block {\n  padding: 10px;\n}\n\n.botom_ad {\n  height: 73px;\n  width: 100%;\n  position: fixed;\n  bottom: 0;\n  padding: 10px;\n  border-radius: 20px;\n}\n\n.action_icons_home {\n  width: 100%;\n  height: 100%;\n  background-size: contain;\n}\n\n.myRequests {\n  color: #123b67;\n  font-weight: 600;\n  padding-top: 10px;\n  font-size: 13px;\n  padding: 10px;\n  text-align: right;\n  text-decoration: underline;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGFzaGJvYXJkL2Rhc2hib2FyZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7RUFDQSxrQ0FBQTtFQUNBLDJCQUFBO0VBQ0EsK0JBQUE7RUFDQSxpQkFBQTtBQUNKOztBQUNBO0VBQ0ksbUJBQUE7QUFFSjs7QUFBRTtFQUNFLFVBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFHSjs7QUFDQTtFQUNFLFdBQUE7QUFFRjs7QUFDRTtFQUNFLHlIQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0FBRUo7O0FBREk7RUFDSSxjQUFBO0VBQ0EsYUFBQTtFQUNKLGVBQUE7QUFHSjs7QUFDRTtFQUNFLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FBRUo7O0FBQUU7RUFFSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFFTjs7QUFDRTtFQUNJLGFBQUE7QUFFTjs7QUFDRTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLFNBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFFSjs7QUFBRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esd0JBQUE7QUFHSjs7QUFDRTtFQUNFLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLDBCQUFBO0FBRUoiLCJmaWxlIjoic3JjL2FwcC9kYXNoYm9hcmQvZGFzaGJvYXJkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXNsaWRlcyB7XHJcbiAgICBoZWlnaHQ6IDI0MHB4O1xyXG4gICAgLS1idWxsZXQtYmFja2dyb3VuZC1hY3RpdmU6IzFhN2NiYztcclxuICAgIC0tYnVsbGV0LWJhY2tncm91bmQgICAgOiMxYTdjYmM7XHJcbiAgICAtLXNjcm9sbC1iYXItYmFja2dyb3VuZDojMWE3Y2JjO1xyXG4gICAgbWFyZ2luLXRvcDogLTMwcHg7XHJcbiAgfVxyXG4uc2xpZGVfaW1hZ2VfYmxvY2t7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG59XHJcbiAgLnNsaWRlX2ltYWdle1xyXG4gICAgd2lkdGg6IDk1JTtcclxuICAgIGhlaWdodDogMTgwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgXHJcbiAgfVxyXG5cclxuLmxvZ291dF9pY29ue1xyXG4gIGNvbG9yOiAjZmZmO1xyXG59XHJcblxyXG4gIC5vcHRpb25ze1xyXG4gICAgYm94LXNoYWRvdzogcmdiYSgwLCAwLCAwLCAwLjIpIDBweCAzcHggMXB4IC0ycHgsIHJnYmEoMCwgMCwgMCwgMC4xNCkgMHB4IDJweCAycHggMHB4LCByZ2JhKDAsIDAsIDAsIDAuMTIpIDBweCAxcHggNXB4IDBweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBmbGV4LWZsb3c6IGNvbHVtbjtcclxuICAgIGhlaWdodDogMTAwcHg7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcbiAgICAuaW9uLWljb257XHJcbiAgICAgICAgY29sb3I6IzFhN2NiYztcclxuICAgICAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLmxhYmVsX2Jsb2Nre1xyXG4gICAgY29sb3I6IzEyM2I2NztcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBwYWRkaW5nLXRvcDogMTBweDtcclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICB9XHJcbiAgLmljb25fb3ZlcmxheXtcclxuICAgICAgLy8gYmFja2dyb3VuZDogI2U5ZjJmOTtcclxuICAgICAgaGVpZ2h0OiA1MHB4O1xyXG4gICAgICB3aWR0aDogNTBweDtcclxuICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgfVxyXG5cclxuICAub3B0aW9uc19ibG9ja3tcclxuICAgICAgcGFkZGluZzoxMHB4IDtcclxuICB9XHJcblxyXG4gIC5ib3RvbV9hZHtcclxuICAgIGhlaWdodDogNzNweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgYm90dG9tOiAwO1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgfVxyXG4gIC5hY3Rpb25faWNvbnNfaG9tZXtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiBjb250YWluO1xyXG4gIH1cclxuICBcclxuXHJcbiAgLm15UmVxdWVzdHN7XHJcbiAgICBjb2xvcjogIzEyM2I2NztcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBwYWRkaW5nLXRvcDogMTBweDtcclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xyXG4gIH0iXX0= */");

/***/ }),

/***/ "./src/app/dashboard/dashboard.component.ts":
/*!**************************************************!*\
  !*** ./src/app/dashboard/dashboard.component.ts ***!
  \**************************************************/
/*! exports provided: DashboardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardComponent", function() { return DashboardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _common_service_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../common/service/storage.service */ "./src/app/common/service/storage.service.ts");
/* harmony import */ var _dashboard_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../dashboard.service */ "./src/app/dashboard.service.ts");





let DashboardComponent = class DashboardComponent {
    constructor(navController, storageSer, dashboardSer) {
        this.navController = navController;
        this.storageSer = storageSer;
        this.dashboardSer = dashboardSer;
        this.slideOpts = {
            initialSlide: 1,
            speed: 400,
            pager: true
        };
    }
    ngOnInit() {
        this.fetchPreRequests();
    }
    register() {
        console.log('register');
        this.navController.navigateForward('verifyAccount');
    }
    navigateTo(url) {
        this.navController.navigateForward(url);
    }
    logOut() {
        this.storageSer.removeAll();
        this.navController.navigateForward('register');
    }
    fetchPreRequests() {
        this.dashboardSer.getAccounts()
            .subscribe((data) => {
            this.dashboardSer.setAccounts(data);
        });
    }
    myRequests() {
        this.navController.navigateForward('myRequests');
    }
};
DashboardComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _common_service_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"] },
    { type: _dashboard_service__WEBPACK_IMPORTED_MODULE_4__["DashboardService"] }
];
DashboardComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-dashboard',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./dashboard.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/dashboard/dashboard.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./dashboard.component.scss */ "./src/app/dashboard/dashboard.component.scss")).default]
    })
], DashboardComponent);



/***/ }),

/***/ "./src/app/ddrequest.service.ts":
/*!**************************************!*\
  !*** ./src/app/ddrequest.service.ts ***!
  \**************************************/
/*! exports provided: DDRequestService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DDRequestService", function() { return DDRequestService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _constant_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./constant/constants */ "./src/app/constant/constants.ts");




let DDRequestService = class DDRequestService {
    constructor(http) {
        this.http = http;
    }
    ddpoRequest(req) {
        return this.http.post(_constant_constants__WEBPACK_IMPORTED_MODULE_3__["API_ENDPOINT"].development + 'ddpoRequest', req);
    }
};
DDRequestService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
];
DDRequestService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], DDRequestService);



/***/ }),

/***/ "./src/app/email-update.service.ts":
/*!*****************************************!*\
  !*** ./src/app/email-update.service.ts ***!
  \*****************************************/
/*! exports provided: EmailUpdateService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmailUpdateService", function() { return EmailUpdateService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_constant_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../app/constant/constants */ "./src/app/constant/constants.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");




let EmailUpdateService = class EmailUpdateService {
    constructor(http) {
        this.http = http;
    }
    changeEmail(req) {
        return this.http.post(_app_constant_constants__WEBPACK_IMPORTED_MODULE_2__["API_ENDPOINT"].development + 'changeEmail', req);
    }
};
EmailUpdateService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }
];
EmailUpdateService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], EmailUpdateService);



/***/ }),

/***/ "./src/app/login.service.ts":
/*!**********************************!*\
  !*** ./src/app/login.service.ts ***!
  \**********************************/
/*! exports provided: LoginService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginService", function() { return LoginService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_constant_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../app/constant/constants */ "./src/app/constant/constants.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");




let LoginService = class LoginService {
    constructor(http) {
        this.http = http;
        console.log("API_ENDPOINT", _app_constant_constants__WEBPACK_IMPORTED_MODULE_2__["API_ENDPOINT"]);
    }
    register(user) {
        return this.http.post(_app_constant_constants__WEBPACK_IMPORTED_MODULE_2__["API_ENDPOINT"].development + 'register', user);
    }
    verifyOTP(OTP) {
        return this.http.post(_app_constant_constants__WEBPACK_IMPORTED_MODULE_2__["API_ENDPOINT"].development + 'verifyOTP', OTP);
    }
    resendOTP(details) {
        return this.http.post(_app_constant_constants__WEBPACK_IMPORTED_MODULE_2__["API_ENDPOINT"].development + 'resendOtp', details);
    }
    setregisterDetails(data) {
        this.registerDetails = data;
    }
    getregisterDetails() {
        return this.registerDetails;
    }
};
LoginService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }
];
LoginService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], LoginService);



/***/ }),

/***/ "./src/app/login/login.component.scss":
/*!********************************************!*\
  !*** ./src/app/login/login.component.scss ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".button_block {\n  padding-top: 50px;\n}\n\n.skip_button_block {\n  margin-top: 20px;\n}\n\n.fingerprint_block {\n  border-radius: 50%;\n  height: 200px;\n  width: 200px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin: 0 auto;\n}\n\n.fingerprint_block .circle_block {\n  padding: 10px;\n  border: 1px solid #1a7cbc;\n  border-radius: 50%;\n  height: 100px;\n  width: 100px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.fingerprint_block .circle_block .touch_icon {\n  color: #fff;\n  font-size: 30px;\n  background-color: #1a7cbc;\n  padding: 10px;\n  display: inline;\n  border-radius: 50%;\n  width: 50px;\n  height: 50px;\n}\n\n.useTouchId {\n  color: #123b67;\n  font-size: 19px;\n  font-weight: 700;\n  text-align: center;\n  padding: 20px 0 10px 0;\n}\n\n.blur_text {\n  color: #abb7ca;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vbG9naW4uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxpQkFBQTtBQUNKOztBQUNBO0VBQ0ksZ0JBQUE7QUFFSjs7QUFDQTtFQUlJLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGNBQUE7QUFESjs7QUFHSTtFQUNJLGFBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQURSOztBQUVRO0VBQ0ksV0FBQTtFQUNBLGVBQUE7RUFDQSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ1IsWUFBQTtBQUFKOztBQUtBO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7QUFGSjs7QUFLQTtFQUNJLGNBQUE7RUFDQSxrQkFBQTtBQUZKIiwiZmlsZSI6InNyYy9hcHAvbG9naW4vbG9naW4uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYnV0dG9uX2Jsb2Nre1xyXG4gICAgcGFkZGluZy10b3A6IDUwcHg7XHJcbn1cclxuLnNraXBfYnV0dG9uX2Jsb2Nre1xyXG4gICAgbWFyZ2luLXRvcDogMjBweDtcclxufVxyXG5cclxuLmZpbmdlcnByaW50X2Jsb2Nre1xyXG5cclxuICAgIC8vIHBhZGRpbmc6IDEwcHg7XHJcbiAgICAvLyBib3JkZXI6IDJweCBzb2xpZCAjYzVjZGQyO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgaGVpZ2h0OiAyMDBweDtcclxuICAgIHdpZHRoOiAyMDBweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBtYXJnaW46IDAgYXV0bztcclxuICAgIC8vIG1hcmdpbi10b3A6IDMwcHg7XHJcbiAgICAuY2lyY2xlX2Jsb2Nre1xyXG4gICAgICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgIzFhN2NiYztcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgaGVpZ2h0OiAxMDBweDtcclxuICAgICAgICB3aWR0aDogMTAwcHg7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgIC50b3VjaF9pY29ue1xyXG4gICAgICAgICAgICBjb2xvcjojZmZmO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDMwcHg7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICMxYTdjYmM7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGlubGluZTtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgICB3aWR0aDogNTBweDtcclxuICAgIGhlaWdodDogNTBweDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi51c2VUb3VjaElke1xyXG4gICAgY29sb3I6ICMxMjNiNjc7XHJcbiAgICBmb250LXNpemU6IDE5cHg7XHJcbiAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgcGFkZGluZzogMjBweCAwIDEwcHggMDtcclxufVxyXG5cclxuLmJsdXJfdGV4dHtcclxuICAgIGNvbG9yOiAjYWJiN2NhO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59Il19 */");

/***/ }),

/***/ "./src/app/login/login.component.ts":
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_fingerprint_aio_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/fingerprint-aio/ngx */ "./node_modules/@ionic-native/fingerprint-aio/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _login_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../login.service */ "./src/app/login.service.ts");





let LoginComponent = class LoginComponent {
    constructor(navController, alertCtrl, faio, loginService) {
        this.navController = navController;
        this.alertCtrl = alertCtrl;
        this.faio = faio;
        this.loginService = loginService;
    }
    ngOnInit() { }
    activate() {
        console.log('dashboard');
        this.openFingerPrint();
        //   this.loginService.login()
        //   .subscribe(data => {
        //     console.log("data", data);
        // });
    }
    skip() {
        this.navController.navigateForward('dashboard');
    }
    openFingerPrint() {
        this.faio.show({
            title: 'Bank Of Maharastra',
            subtitle: 'One of the top 5 banks in India.' // (Android Only) | optional | Default: null
            // description: 'Please authenticate' // optional | Default: null
            // fallbackButtonTitle: 'Use Backup', // optional | When disableBackup is false defaults to "Use Pin".
            // When disableBackup is true defaults to "Cancel"
            // disableBackup:true,  // optional | default: false
        })
            .then((result) => {
            console.log(result);
            this.navController.navigateForward('dashboard');
        })
            .catch((error) => this.presentAlert(error.message));
    }
    presentAlert(message) {
        message = message.replaceAll('_', ' ');
        alert(message);
    }
};
LoginComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_native_fingerprint_aio_ngx__WEBPACK_IMPORTED_MODULE_3__["FingerprintAIO"] },
    { type: _login_service__WEBPACK_IMPORTED_MODULE_4__["LoginService"] }
];
LoginComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-login',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./login.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./login.component.scss */ "./src/app/login/login.component.scss")).default]
    })
], LoginComponent);



/***/ }),

/***/ "./src/app/my-requests/my-requests.component.scss":
/*!********************************************************!*\
  !*** ./src/app/my-requests/my-requests.component.scss ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".listviewImage {\n  width: 100%;\n  height: 100%;\n  background-size: contain;\n}\n\n.eachItem {\n  margin-bottom: 5px;\n  box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 1px 5px 0px;\n}\n\nion-content {\n  border-top: 7px !important;\n}\n\n.noRequests {\n  display: flex;\n  height: 86%;\n  width: 100%;\n  position: fixed;\n  align-items: center;\n  justify-content: center;\n  flex-flow: column;\n  color: gray;\n  font-size: 23px;\n  font-weight: 100;\n  text-transform: uppercase;\n  position: absolute;\n  bottom: 68px;\n  right: 10px;\n}\n\n.labelText {\n  color: #123b67;\n  font-weight: 600;\n}\n\n.dateText {\n  color: #123b67;\n  font-weight: 500;\n  padding-top: 5px;\n}\n\n.status {\n  text-transform: uppercase;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbXktcmVxdWVzdHMvbXktcmVxdWVzdHMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHdCQUFBO0FBQ0o7O0FBRUU7RUFFRSxrQkFBQTtFQUNBLHlIQUFBO0FBQUo7O0FBR0U7RUFDRSwwQkFBQTtBQUFKOztBQUdFO0VBQ0UsYUFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxpQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUFBSjs7QUFHRTtFQUNFLGNBQUE7RUFDQSxnQkFBQTtBQUFKOztBQUVFO0VBQ0UsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7QUFDSjs7QUFDRTtFQUNFLHlCQUFBO0FBRUoiLCJmaWxlIjoic3JjL2FwcC9teS1yZXF1ZXN0cy9teS1yZXF1ZXN0cy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5saXN0dmlld0ltYWdle1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGNvbnRhaW47XHJcbiAgfVxyXG5cclxuICAuZWFjaEl0ZW17XHJcblxyXG4gICAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG4gICAgYm94LXNoYWRvdzogcmdiYSgwLCAwLCAwLCAwLjIpIDBweCAzcHggMXB4IC0ycHgsIHJnYmEoMCwgMCwgMCwgMC4xNCkgMHB4IDJweCAycHggMHB4LCByZ2JhKDAsIDAsIDAsIDAuMTIpIDBweCAxcHggNXB4IDBweDtcclxuICB9XHJcblxyXG4gIGlvbi1jb250ZW50e1xyXG4gICAgYm9yZGVyLXRvcDogN3B4ICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG5cclxuICAubm9SZXF1ZXN0c3tcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBoZWlnaHQ6IDg2JTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZmxleC1mbG93OiBjb2x1bW47XHJcbiAgICBjb2xvcjogZ3JheTtcclxuICAgIGZvbnQtc2l6ZTogMjNweDtcclxuICAgIGZvbnQtd2VpZ2h0OiAxMDA7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgYm90dG9tOiA2OHB4O1xyXG4gICAgcmlnaHQ6IDEwcHg7XHJcbiAgfVxyXG5cclxuICAubGFiZWxUZXh0e1xyXG4gICAgY29sb3I6ICMxMjNiNjc7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gIH1cclxuICAuZGF0ZVRleHR7XHJcbiAgICBjb2xvcjogIzEyM2I2NztcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICBwYWRkaW5nLXRvcDogNXB4O1xyXG4gIH1cclxuICAuc3RhdHVzeyAgICBcclxuICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbn0iXX0= */");

/***/ }),

/***/ "./src/app/my-requests/my-requests.component.ts":
/*!******************************************************!*\
  !*** ./src/app/my-requests/my-requests.component.ts ***!
  \******************************************************/
/*! exports provided: REQUEST_STATUS, COLORS_CODE, REQUEST_TYPE, MyRequestsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "REQUEST_STATUS", function() { return REQUEST_STATUS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "COLORS_CODE", function() { return COLORS_CODE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "REQUEST_TYPE", function() { return REQUEST_TYPE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyRequestsComponent", function() { return MyRequestsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _common_service_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../common/service/storage.service */ "./src/app/common/service/storage.service.ts");
/* harmony import */ var _email_update_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../email-update.service */ "./src/app/email-update.service.ts");
/* harmony import */ var _requests_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../requests.service */ "./src/app/requests.service.ts");






var REQUEST_STATUS;
(function (REQUEST_STATUS) {
    REQUEST_STATUS["Pending"] = "Pending";
    REQUEST_STATUS["Approved"] = "approved";
    REQUEST_STATUS["Rejected"] = "rejected";
})(REQUEST_STATUS || (REQUEST_STATUS = {}));
;
var COLORS_CODE;
(function (COLORS_CODE) {
    COLORS_CODE["Pending"] = "#FFC107";
    COLORS_CODE["Approved"] = "#19a919";
    COLORS_CODE["Rejected"] = "#FF5722";
})(COLORS_CODE || (COLORS_CODE = {}));
;
var REQUEST_TYPE;
(function (REQUEST_TYPE) {
    REQUEST_TYPE["EMAIL"] = "Email Update";
    REQUEST_TYPE["PAN"] = "PAN Update";
    REQUEST_TYPE["DDPO"] = "DD Request";
    REQUEST_TYPE["SCHEMES"] = "PM Request";
})(REQUEST_TYPE || (REQUEST_TYPE = {}));
;
let MyRequestsComponent = class MyRequestsComponent {
    // Email: FormGroup;
    constructor(navController, modalController, storageSer, emailUpdateService, reqSer) {
        this.navController = navController;
        this.modalController = modalController;
        this.storageSer = storageSer;
        this.emailUpdateService = emailUpdateService;
        this.reqSer = reqSer;
        this.REQUEST_STATUS = REQUEST_STATUS;
        this.REQUEST_TYPE = REQUEST_TYPE;
        this.COLORS_CODE = COLORS_CODE;
        this.requests = [];
        //     {
        //     type:0,
        //     date:new Date(),
        //     status:0
        //   },{
        //     type:1,
        //     date:new Date(),
        //     status:1
        //   },{
        //     type:2,
        //     date:new Date(),
        //     status:2
        //   }
        // ];
        this.error = "";
        this.apiResponded = false;
    }
    ngOnInit() {
        this.apiResponded = false;
        this.getRequests();
    }
    back() {
        this.navController.back();
    }
    getRequests() {
        let custId = this.storageSer.getItem('customerId');
        this.reqSer.getRequests(custId)
            .subscribe((data) => {
            this.requests = data.data;
            this.apiResponded = true;
        });
    }
};
MyRequestsComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _common_service_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"] },
    { type: _email_update_service__WEBPACK_IMPORTED_MODULE_4__["EmailUpdateService"] },
    { type: _requests_service__WEBPACK_IMPORTED_MODULE_5__["RequestsService"] }
];
MyRequestsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-my-requests',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./my-requests.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/my-requests/my-requests.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./my-requests.component.scss */ "./src/app/my-requests/my-requests.component.scss")).default]
    })
], MyRequestsComponent);



/***/ }),

/***/ "./src/app/offers.service.ts":
/*!***********************************!*\
  !*** ./src/app/offers.service.ts ***!
  \***********************************/
/*! exports provided: OffersService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OffersService", function() { return OffersService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_constant_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../app/constant/constants */ "./src/app/constant/constants.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");




let OffersService = class OffersService {
    constructor(http) {
        this.http = http;
    }
    getOffers(custId) {
        return this.http.get(_app_constant_constants__WEBPACK_IMPORTED_MODULE_2__["API_ENDPOINT"].development + 'offersList/' + custId);
    }
};
OffersService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }
];
OffersService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], OffersService);



/***/ }),

/***/ "./src/app/pan-update.service.ts":
/*!***************************************!*\
  !*** ./src/app/pan-update.service.ts ***!
  \***************************************/
/*! exports provided: PanUpdateService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PanUpdateService", function() { return PanUpdateService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_constant_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../app/constant/constants */ "./src/app/constant/constants.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");




let PanUpdateService = class PanUpdateService {
    constructor(http) {
        this.http = http;
    }
    changePan(pan) {
        const HttpUploadOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({ "Content-Type": "multipart/form-data" })
        };
        return this.http.post(_app_constant_constants__WEBPACK_IMPORTED_MODULE_2__["API_ENDPOINT"].development + 'panDetails', pan);
    }
};
PanUpdateService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }
];
PanUpdateService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], PanUpdateService);



/***/ }),

/***/ "./src/app/pm-schemes.service.ts":
/*!***************************************!*\
  !*** ./src/app/pm-schemes.service.ts ***!
  \***************************************/
/*! exports provided: PmSchemesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PmSchemesService", function() { return PmSchemesService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_constant_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../app/constant/constants */ "./src/app/constant/constants.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");




let PmSchemesService = class PmSchemesService {
    constructor(http) {
        this.http = http;
        console.log("API_ENDPOINT", _app_constant_constants__WEBPACK_IMPORTED_MODULE_2__["API_ENDPOINT"]);
    }
    getSchemes() {
        return this.http.get(_app_constant_constants__WEBPACK_IMPORTED_MODULE_2__["API_ENDPOINT"].development + 'PMSchemes');
    }
    createScheme(scheme) {
        return this.http.post(_app_constant_constants__WEBPACK_IMPORTED_MODULE_2__["API_ENDPOINT"].development + 'createScheme', scheme);
    }
};
PmSchemesService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }
];
PmSchemesService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], PmSchemesService);



/***/ }),

/***/ "./src/app/pm-schemes/pm-schemes.component.scss":
/*!******************************************************!*\
  !*** ./src/app/pm-schemes/pm-schemes.component.scss ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".button_block {\n  padding-top: 50px;\n}\n\n.cust_id {\n  color: #123b67;\n  font-weight: 600;\n  padding-bottom: 14px;\n  text-align: left;\n  border-bottom: 1px solid #123b67;\n  margin-bottom: 4px;\n}\n\n.slect_box {\n  width: 100%;\n}\n\n.scheme_details {\n  background-color: #edf0f9;\n  color: #123b67;\n  font-weight: 600;\n  padding: 10px;\n  border-radius: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcG0tc2NoZW1lcy9wbS1zY2hlbWVzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksaUJBQUE7QUFDSjs7QUFFQTtFQUNJLGNBQUE7RUFDQSxnQkFBQTtFQUNBLG9CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQ0FBQTtFQUNBLGtCQUFBO0FBQ0o7O0FBQ0E7RUFDSSxXQUFBO0FBRUo7O0FBQ0E7RUFDSSx5QkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQUVKIiwiZmlsZSI6InNyYy9hcHAvcG0tc2NoZW1lcy9wbS1zY2hlbWVzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJ1dHRvbl9ibG9ja3tcclxuICAgIHBhZGRpbmctdG9wOiA1MHB4O1xyXG59XHJcblxyXG4uY3VzdF9pZHtcclxuICAgIGNvbG9yOiAjMTIzYjY3O1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxNHB4O1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMTIzYjY3O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNHB4O1xyXG59XHJcbi5zbGVjdF9ib3h7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG5cclxuLnNjaGVtZV9kZXRhaWxze1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjojZWRmMGY5O1xyXG4gICAgY29sb3I6ICMxMjNiNjc7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgcGFkZGluZzoxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxufSJdfQ== */");

/***/ }),

/***/ "./src/app/pm-schemes/pm-schemes.component.ts":
/*!****************************************************!*\
  !*** ./src/app/pm-schemes/pm-schemes.component.ts ***!
  \****************************************************/
/*! exports provided: PmSchemesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PmSchemesComponent", function() { return PmSchemesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _success_modal_success_modal_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../success-modal/success-modal.component */ "./src/app/success-modal/success-modal.component.ts");
/* harmony import */ var _pm_schemes_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../pm-schemes.service */ "./src/app/pm-schemes.service.ts");
/* harmony import */ var _common_service_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common/service/storage.service */ "./src/app/common/service/storage.service.ts");
/* harmony import */ var _dashboard_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../dashboard.service */ "./src/app/dashboard.service.ts");







let PmSchemesComponent = class PmSchemesComponent {
    constructor(navController, modalController, storageSer, pmSchemesService, dashboardSer) {
        this.navController = navController;
        this.modalController = modalController;
        this.storageSer = storageSer;
        this.pmSchemesService = pmSchemesService;
        this.dashboardSer = dashboardSer;
        this.accounts = [];
        this.customchooseAccOptions = {
            header: 'Account Numbers',
        };
        this.schemeDetails = {};
        this.selectedScheme = {
            totalDisabilityInsurence: '',
            partialDisabilityInsurence: '',
            premium: '',
        };
        this.customActionSheetOptions = {
            header: 'Schemes',
        };
        this.schemes = [];
        this.scheme = {};
    }
    ngOnInit() {
        this.getSchemes();
        this.userDetails = JSON.parse(this.storageSer.getItem('registerDetails'));
        this.accounts = this.dashboardSer.getStoredAccounts();
    }
    pmSchemeSubmit() {
        console.log('pmSchemeSubmit');
        this.createScheme(this.selectedScheme);
    }
    getSchemes() {
        this.pmSchemesService.getSchemes()
            .subscribe((data) => {
            this.schemes = data.schemes;
            this.selectedScheme = this.schemes[0];
        });
    }
    createScheme(scheme) {
        let reqObj = {
            customerId: this.userDetails.customerId,
            customerName: this.userDetails.customerName,
            branchId: this.userDetails.branchId,
            code: this.selectedScheme.code,
            accountNumber: this.selectedAccount
        };
        this.pmSchemesService.createScheme(reqObj)
            .subscribe((data) => {
            console.log("data", data);
            this.presentActionSheet();
        });
    }
    onChangeScheme(schm) {
        setTimeout(() => this.schemeDetails = schm, 300);
    }
    back() {
        this.navController.back();
    }
    presentActionSheet() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _success_modal_success_modal_component__WEBPACK_IMPORTED_MODULE_3__["SuccessModalComponent"],
                cssClass: 'successModal',
                backdropDismiss: true,
            });
            modal.onDidDismiss().then(data => {
                console.log('dismissed', data);
                this.navController.pop();
            });
            setTimeout(() => { if (modal) {
                modal.dismiss();
            } }, 3000);
            return yield modal.present();
        });
    }
};
PmSchemesComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _common_service_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"] },
    { type: _pm_schemes_service__WEBPACK_IMPORTED_MODULE_4__["PmSchemesService"] },
    { type: _dashboard_service__WEBPACK_IMPORTED_MODULE_6__["DashboardService"] }
];
PmSchemesComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-pm-schemes',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./pm-schemes.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pm-schemes/pm-schemes.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./pm-schemes.component.scss */ "./src/app/pm-schemes/pm-schemes.component.scss")).default]
    })
], PmSchemesComponent);



/***/ }),

/***/ "./src/app/pre-approved-offers/pre-approved-offers.component.scss":
/*!************************************************************************!*\
  !*** ./src/app/pre-approved-offers/pre-approved-offers.component.scss ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".each_offer ion-button {\n  text-align: left;\n}\n\nion-content {\n  border-top: 7px !important;\n}\n\nion-item {\n  border: 0 !important;\n}\n\nion-item .item-native.item-inner {\n  border: 0 !important;\n}\n\n.listItems {\n  padding: 15px;\n  color: #113a69;\n  border-radius: 10px;\n  margin-bottom: 5px;\n  box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 1px 5px 0px;\n}\n\n.listItems .labelText {\n  color: #123b67;\n  font-weight: 600;\n}\n\n.bottomOverlay {\n  height: 60px;\n  background: linear-gradient(to top, #113A69 0%, #0E88D3 100%);\n}\n\n.noRequests {\n  display: flex;\n  height: 86%;\n  width: 100%;\n  position: fixed;\n  align-items: center;\n  justify-content: center;\n  flex-flow: column;\n  color: gray;\n  font-size: 23px;\n  font-weight: 100;\n  text-transform: uppercase;\n  position: absolute;\n  bottom: 68px;\n  right: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJlLWFwcHJvdmVkLW9mZmVycy9wcmUtYXBwcm92ZWQtb2ZmZXJzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVJO0VBQ0ksZ0JBQUE7QUFEUjs7QUFJQTtFQUNJLDBCQUFBO0FBREo7O0FBSUE7RUFDSSxvQkFBQTtBQURKOztBQUVJO0VBQ0ksb0JBQUE7QUFBUjs7QUFJQTtFQUNJLGFBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLHlIQUFBO0FBREo7O0FBR0k7RUFDSSxjQUFBO0VBQ0EsZ0JBQUE7QUFEUjs7QUFJQTtFQUNJLFlBQUE7RUFDQSw2REFBQTtBQURKOztBQUtBO0VBQ0ksYUFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxpQkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUFGSiIsImZpbGUiOiJzcmMvYXBwL3ByZS1hcHByb3ZlZC1vZmZlcnMvcHJlLWFwcHJvdmVkLW9mZmVycy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5lYWNoX29mZmVye1xyXG4gICAgLy8gcGFkZGluZy1ib3R0b206IDE1cHg7XHJcbiAgICBpb24tYnV0dG9ue1xyXG4gICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICB9XHJcbn1cclxuaW9uLWNvbnRlbnR7XHJcbiAgICBib3JkZXItdG9wOiA3cHggIWltcG9ydGFudDtcclxuICB9XHJcblxyXG5pb24taXRlbXtcclxuICAgIGJvcmRlcjogMCAhaW1wb3J0YW50O1xyXG4gICAgLml0ZW0tbmF0aXZlLml0ZW0taW5uZXJ7XHJcbiAgICAgICAgYm9yZGVyOiAwICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5saXN0SXRlbXN7XHJcbiAgICBwYWRkaW5nOiAxNXB4O1xyXG4gICAgY29sb3I6ICMxMTNhNjk7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG4gICAgYm94LXNoYWRvdzogcmdiYSgwLCAwLCAwLCAwLjIpIDBweCAzcHggMXB4IC0ycHgsIHJnYmEoMCwgMCwgMCwgMC4xNCkgMHB4IDJweCAycHggMHB4LCByZ2JhKDAsIDAsIDAsIDAuMTIpIDBweCAxcHggNXB4IDBweDtcclxuXHJcbiAgICAubGFiZWxUZXh0e1xyXG4gICAgICAgIGNvbG9yOiAjMTIzYjY3O1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgIH1cclxufVxyXG4uYm90dG9tT3ZlcmxheXtcclxuICAgIGhlaWdodDogNjBweDtcclxuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byB0b3AsICMxMTNBNjkgMCUsICMwRTg4RDMgMTAwJSk7XHJcbn1cclxuXHJcblxyXG4ubm9SZXF1ZXN0c3tcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBoZWlnaHQ6IDg2JTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZmxleC1mbG93OiBjb2x1bW47XHJcbiAgICBjb2xvcjogZ3JheTtcclxuICAgIGZvbnQtc2l6ZTogMjNweDtcclxuICAgIGZvbnQtd2VpZ2h0OiAxMDA7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgYm90dG9tOiA2OHB4O1xyXG4gICAgcmlnaHQ6IDEwcHg7XHJcbiAgfVxyXG4iXX0= */");

/***/ }),

/***/ "./src/app/pre-approved-offers/pre-approved-offers.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/pre-approved-offers/pre-approved-offers.component.ts ***!
  \**********************************************************************/
/*! exports provided: PreApprovedOffersComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreApprovedOffersComponent", function() { return PreApprovedOffersComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _offers_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../offers.service */ "./src/app/offers.service.ts");
/* harmony import */ var _common_service_storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../common/service/storage.service */ "./src/app/common/service/storage.service.ts");





let PreApprovedOffersComponent = class PreApprovedOffersComponent {
    constructor(navController, offersService, storageSer, chr) {
        this.navController = navController;
        this.offersService = offersService;
        this.storageSer = storageSer;
        this.chr = chr;
        this.offers = [];
        /*
        {
          name:"Lifetime Free Credit Card",
          id:1,
          description:'BOM allows you to purchage life time free credit card.'
        },
        {
          name:"Personal loan upto 500000",
          id:1,
          description:'BOM allows you to purchage life time free credit card.'
        },{
          name:"car loadn",
          id:1,
          description:'BOM allows you to purchage life time free credit card.'
        },{
          name:"Jwele loan for 6%",
          id:1,
          description:'BOM allows you to purchage life time free credit card.'
        }*/
        this.apiResponded = false;
    }
    ngOnInit() {
        this.apiResponded = false;
        this.getRequests();
    }
    back() {
        this.navController.back();
    }
    getRequests() {
        let custId = this.storageSer.getItem('customerId');
        this.offersService.getOffers(custId)
            .subscribe((data) => {
            this.apiResponded = true;
            this.offers = data.data;
            console.log('this.offers,this.offers);', this.offers);
            setTimeout(() => {
                this.apiResponded = true;
                this.chr.detectChanges();
            }, 100);
        });
    }
};
PreApprovedOffersComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _offers_service__WEBPACK_IMPORTED_MODULE_3__["OffersService"] },
    { type: _common_service_storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"] }
];
PreApprovedOffersComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-pre-approved-offers',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./pre-approved-offers.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pre-approved-offers/pre-approved-offers.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./pre-approved-offers.component.scss */ "./src/app/pre-approved-offers/pre-approved-offers.component.scss")).default]
    })
], PreApprovedOffersComponent);



/***/ }),

/***/ "./src/app/register/register.component.scss":
/*!**************************************************!*\
  !*** ./src/app/register/register.component.scss ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".button_block {\n  padding-top: 60px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVnaXN0ZXIvcmVnaXN0ZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxpQkFBQTtBQUNKIiwiZmlsZSI6InNyYy9hcHAvcmVnaXN0ZXIvcmVnaXN0ZXIuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYnV0dG9uX2Jsb2Nre1xyXG4gICAgcGFkZGluZy10b3A6IDYwcHg7XHJcbn0iXX0= */");

/***/ }),

/***/ "./src/app/register/register.component.ts":
/*!************************************************!*\
  !*** ./src/app/register/register.component.ts ***!
  \************************************************/
/*! exports provided: RegisterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterComponent", function() { return RegisterComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _common_constants_apiErrorMessages_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../common/constants/apiErrorMessages.constants */ "./src/app/common/constants/apiErrorMessages.constants.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _common_errHandler_errorhandler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common/errHandler/errorhandler */ "./src/app/common/errHandler/errorhandler.ts");
/* harmony import */ var _common_constants_regExp_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../common/constants/regExp.constants */ "./src/app/common/constants/regExp.constants.ts");
/* harmony import */ var _login_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../login.service */ "./src/app/login.service.ts");
/* harmony import */ var _customer_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../customer.service */ "./src/app/customer.service.ts");
/* harmony import */ var _common_service_storage_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../common/service/storage.service */ "./src/app/common/service/storage.service.ts");










let RegisterComponent = class RegisterComponent {
    constructor(navController, formBuilder, alertController, loginService, customerService, storageSer) {
        this.navController = navController;
        this.formBuilder = formBuilder;
        this.alertController = alertController;
        this.loginService = loginService;
        this.customerService = customerService;
        this.storageSer = storageSer;
        this.user = {
            accountNo: '',
            mobileNo: ''
        };
        this.error = ' ';
        this.appErrorMessages = _common_constants_apiErrorMessages_constants__WEBPACK_IMPORTED_MODULE_3__["APP_ERROR_MESSAGES"];
        this.matcher = new _common_errHandler_errorhandler__WEBPACK_IMPORTED_MODULE_5__["MyErrorStateMatcher"]();
    }
    ngOnInit() { }
    registerUser() {
        if (this.validateForm()) {
            console.log('register');
            this.loginService.register(this.user)
                .subscribe((data) => {
                if (data.data.customerId) {
                    this.loginService.setregisterDetails(this.user);
                    this.storageSer.setItem("customerId", data.data.customerId);
                    this.storageSer.setItem("authtoken", data.accessToken);
                    data.data.branchId = "12345",
                        this.storageSer.setItem("registerDetails", JSON.stringify(data.data));
                    this.customerService.setCustomer(data);
                    this.navController.navigateForward('verifyAccount');
                }
            });
        }
    }
    clearErr() {
        this.error = ' ';
    }
    validateForm() {
        console.log('REGEX_PATTERNS.phone.test(this.user.mobileNo', _common_constants_regExp_constants__WEBPACK_IMPORTED_MODULE_6__["REGEX_PATTERNS"].accountNo.test(this.user.accountNo));
        if (!_common_constants_regExp_constants__WEBPACK_IMPORTED_MODULE_6__["REGEX_PATTERNS"].accountNo.test(this.user.accountNo)) {
            this.error = _common_constants_apiErrorMessages_constants__WEBPACK_IMPORTED_MODULE_3__["APP_ERROR_MESSAGES"].invalidAccNo;
            return false;
        }
        if (!_common_constants_regExp_constants__WEBPACK_IMPORTED_MODULE_6__["REGEX_PATTERNS"].phone.test(this.user.mobileNo)) {
            this.error = _common_constants_apiErrorMessages_constants__WEBPACK_IMPORTED_MODULE_3__["APP_ERROR_MESSAGES"].invalidMobileNo;
            return false;
        }
        return true;
        ;
    }
    displayMessage(headerMsg, desc) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'alert_popup',
                header: headerMsg,
                message: desc,
                buttons: ['OK']
            });
            yield alert.present();
        });
    }
    clear() {
        this.user.accountNo = '';
        this.user.mobileNo = '';
    }
    back() {
        this.navController.back();
    }
};
RegisterComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _login_service__WEBPACK_IMPORTED_MODULE_7__["LoginService"] },
    { type: _customer_service__WEBPACK_IMPORTED_MODULE_8__["CustomerService"] },
    { type: _common_service_storage_service__WEBPACK_IMPORTED_MODULE_9__["StorageService"] }
];
RegisterComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-register',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./register.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./register.component.scss */ "./src/app/register/register.component.scss")).default]
    })
], RegisterComponent);



/***/ }),

/***/ "./src/app/request-dd-po/request-dd-po.component.scss":
/*!************************************************************!*\
  !*** ./src/app/request-dd-po/request-dd-po.component.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".button_block {\n  padding-top: 25px;\n}\n\n.cust_id {\n  color: #123b67;\n  font-weight: 600;\n  padding-bottom: 14px;\n  text-align: left;\n  border-bottom: 1px solid #123b67;\n  margin-bottom: 10px;\n  padding-left: 10px;\n}\n\n.slect_box {\n  width: 100%;\n}\n\n.scheme_details {\n  background-color: #edf0f9;\n  color: #123b67;\n  font-weight: 600;\n  padding: 10px;\n  border-radius: 10px;\n}\n\n.label_padding_1 {\n  padding-left: 10px;\n  padding-bottom: 10px;\n}\n\n.radios {\n  display: flex;\n  align-items: center;\n  box-shadow: none;\n}\n\n.radios .label_radio {\n  padding-left: 10px;\n  color: #123b67 !important;\n  font-weight: 500;\n}\n\n.commisionBlock {\n  display: flex;\n  padding: 10px;\n  flex-direction: column;\n  margin-bottom: 15px;\n  box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 1px 5px 0px;\n}\n\n.commisionBlock .eachBlock {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n  color: #113A69;\n  font-weight: 550;\n  padding: 15px 0;\n}\n\n.commisionBlock .bottomBorder {\n  border-bottom: 1px solid #113A69;\n}\n\n.commisionBlock .commisionAmt {\n  color: orange;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVxdWVzdC1kZC1wby9yZXF1ZXN0LWRkLXBvLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksaUJBQUE7QUFDSjs7QUFFQTtFQUNJLGNBQUE7RUFDQSxnQkFBQTtFQUNBLG9CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQ0FBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFDSjs7QUFDQTtFQUNJLFdBQUE7QUFFSjs7QUFDQTtFQUNJLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBRUo7O0FBQ0E7RUFDSSxrQkFBQTtFQUNBLG9CQUFBO0FBRUo7O0FBQ0E7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtBQUVKOztBQUFJO0VBQ0ksa0JBQUE7RUFDQSx5QkFBQTtFQUNKLGdCQUFBO0FBRUo7O0FBRUE7RUFDSSxhQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSx5SEFBQTtBQUNKOztBQUFJO0VBQ0ksYUFBQTtFQUNKLG1CQUFBO0VBQ0EsOEJBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFFQSxlQUFBO0FBQ0o7O0FBQ0k7RUFDSSxnQ0FBQTtBQUNSOztBQUNJO0VBQ0ksYUFBQTtBQUNSIiwiZmlsZSI6InNyYy9hcHAvcmVxdWVzdC1kZC1wby9yZXF1ZXN0LWRkLXBvLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJ1dHRvbl9ibG9ja3tcclxuICAgIHBhZGRpbmctdG9wOiAyNXB4O1xyXG59XHJcblxyXG4uY3VzdF9pZHtcclxuICAgIGNvbG9yOiAjMTIzYjY3O1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxNHB4O1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMTIzYjY3O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICAgIHBhZGRpbmctbGVmdDogMTBweDtcclxufVxyXG4uc2xlY3RfYm94e1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbi5zY2hlbWVfZGV0YWlsc3tcclxuICAgIGJhY2tncm91bmQtY29sb3I6I2VkZjBmOTtcclxuICAgIGNvbG9yOiAjMTIzYjY3O1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgIHBhZGRpbmc6MTBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbn1cclxuXHJcbi5sYWJlbF9wYWRkaW5nXzF7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcclxufVxyXG5cclxuLnJhZGlvc3tcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgYm94LXNoYWRvdzogbm9uZTtcclxuICAgIFxyXG4gICAgLmxhYmVsX3JhZGlve1xyXG4gICAgICAgIHBhZGRpbmctbGVmdDogMTBweDtcclxuICAgICAgICBjb2xvcjogIzEyM2I2NyAhaW1wb3J0YW50O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIH1cclxufVxyXG5cclxuLmNvbW1pc2lvbkJsb2Nre1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxuICAgIGJveC1zaGFkb3c6IHJnYmEoMCwgMCwgMCwgMC4yKSAwcHggM3B4IDFweCAtMnB4LCByZ2JhKDAsIDAsIDAsIDAuMTQpIDBweCAycHggMnB4IDBweCwgcmdiYSgwLCAwLCAwLCAwLjEyKSAwcHggMXB4IDVweCAwcHg7XHJcbiAgICAuZWFjaEJsb2Nre1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgY29sb3I6ICMxMTNBNjk7XHJcbiAgICBmb250LXdlaWdodDogNTUwO1xyXG4gICBcclxuICAgIHBhZGRpbmc6IDE1cHggMDtcclxuICAgIH1cclxuICAgIC5ib3R0b21Cb3JkZXJ7XHJcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICMxMTNBNjk7XHJcbiAgICB9XHJcbiAgICAuY29tbWlzaW9uQW10e1xyXG4gICAgICAgIGNvbG9yOiBvcmFuZ2U7XHJcbiAgICB9XHJcbn0iXX0= */");

/***/ }),

/***/ "./src/app/request-dd-po/request-dd-po.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/request-dd-po/request-dd-po.component.ts ***!
  \**********************************************************/
/*! exports provided: RequestDdPoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequestDdPoComponent", function() { return RequestDdPoComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ddrequest_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../ddrequest.service */ "./src/app/ddrequest.service.ts");
/* harmony import */ var _success_modal_success_modal_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../success-modal/success-modal.component */ "./src/app/success-modal/success-modal.component.ts");
/* harmony import */ var _common_service_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common/service/storage.service */ "./src/app/common/service/storage.service.ts");
/* harmony import */ var _dashboard_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../dashboard.service */ "./src/app/dashboard.service.ts");
/* harmony import */ var _common_constants_regExp_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../common/constants/regExp.constants */ "./src/app/common/constants/regExp.constants.ts");
/* harmony import */ var _common_constants_apiErrorMessages_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../common/constants/apiErrorMessages.constants */ "./src/app/common/constants/apiErrorMessages.constants.ts");









let RequestDdPoComponent = class RequestDdPoComponent {
    constructor(navController, modalController, ddRequestService, storageSer, dashboardSer) {
        this.navController = navController;
        this.modalController = modalController;
        this.ddRequestService = ddRequestService;
        this.storageSer = storageSer;
        this.dashboardSer = dashboardSer;
        this.error = "";
        this.customchooseAccOptions = {
            header: 'Account Numbers',
        };
        this.customActionSheetOptions = {
            header: 'Schemes',
        };
        this.fromBranch = "0";
        this.accounts = [];
        this.ddpo = {
            payeeName: "",
            ddAmount: null,
            // commission: "",
            // totalAmount: "",
            payebleAt: "",
            delivery: "",
            address1: "",
            address2: "",
            pinCode: "",
            customerName: "",
            customerId: "",
            accountNumber: ""
        };
        this.commissionAmount = 0;
    }
    ngOnInit() {
        this.userDetails = JSON.parse(this.storageSer.getItem('registerDetails'));
        this.accounts = this.dashboardSer.getStoredAccounts();
    }
    createddpo() {
        console.log('changeEmail');
        if (this.validate()) {
            this.ddpo.customerName = this.userDetails.customerName;
            this.ddpo.customerId = this.userDetails.customerId;
            this.ddpo.branchId = this.userDetails.branchId;
            this.ddpo.fromBranch = this.fromBranch == "0" ? "true" : "false";
            this.ddpo.fromDelivery = this.fromBranch == "0" ? "false" : "true";
            // }
            // this.presentActionSheet();
            this.ddRequestService.ddpoRequest(this.ddpo)
                .subscribe(data => {
                console.log("data", data);
                //     if(data.data.customerId){
                //       localStorage.setItem("customerId",data.data.customerId);
                //       this.navController.navigateForward('verifyAccount');
                //     }
                // });
                this.presentActionSheet();
            });
        }
    }
    validate() {
        if (!_common_constants_regExp_constants__WEBPACK_IMPORTED_MODULE_7__["REGEX_PATTERNS"].pinCode.test(this.ddpo.pinCode)) {
            this.error = _common_constants_apiErrorMessages_constants__WEBPACK_IMPORTED_MODULE_8__["APP_ERROR_MESSAGES"].invalidPin;
            return false;
        }
        return true;
    }
    back() {
        this.navController.back();
    }
    presentActionSheet() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _success_modal_success_modal_component__WEBPACK_IMPORTED_MODULE_4__["SuccessModalComponent"],
                cssClass: 'successModal',
                backdropDismiss: true,
            });
            modal.onDidDismiss().then(data => {
                console.log('dismissed', data);
                this.navController.pop();
            });
            setTimeout(() => { if (modal) {
                modal.dismiss();
            } }, 3000);
            return yield modal.present();
        });
    }
    clearErr() {
        this.error = "";
    }
    updateCommission() {
        console.log('updateCommission');
        if (this.ddpo.ddAmount < 5000) {
            this.commissionAmount = 300;
        }
        else if (this.ddpo.ddAmount < 20000) {
            this.commissionAmount = 500;
        }
        else {
            this.commissionAmount = 800;
        }
        this.totalPay = Number(this.commissionAmount) + Number(this.ddpo.ddAmount);
    }
};
RequestDdPoComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _ddrequest_service__WEBPACK_IMPORTED_MODULE_3__["DDRequestService"] },
    { type: _common_service_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"] },
    { type: _dashboard_service__WEBPACK_IMPORTED_MODULE_6__["DashboardService"] }
];
RequestDdPoComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-request-dd-po',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./request-dd-po.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/request-dd-po/request-dd-po.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./request-dd-po.component.scss */ "./src/app/request-dd-po/request-dd-po.component.scss")).default]
    })
], RequestDdPoComponent);



/***/ }),

/***/ "./src/app/requests.service.ts":
/*!*************************************!*\
  !*** ./src/app/requests.service.ts ***!
  \*************************************/
/*! exports provided: RequestsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequestsService", function() { return RequestsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _app_constant_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../app/constant/constants */ "./src/app/constant/constants.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");




let RequestsService = class RequestsService {
    constructor(http) {
        this.http = http;
    }
    getRequests(custId) {
        return this.http.get(_app_constant_constants__WEBPACK_IMPORTED_MODULE_2__["API_ENDPOINT"].development + 'allRequests/' + custId);
    }
};
RequestsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }
];
RequestsService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], RequestsService);



/***/ }),

/***/ "./src/app/success-modal/success-modal.component.scss":
/*!************************************************************!*\
  !*** ./src/app/success-modal/success-modal.component.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".Success_modal {\n  position: absolute;\n  bottom: 0;\n  height: 240px;\n  background: transparent;\n  background: #fff;\n  width: 100%;\n  border-top-left-radius: 20px;\n  border-top-right-radius: 20px;\n  padding: 20px;\n}\n.Success_modal .modal-wrapper {\n  background: transparent;\n}\n.Success_modal .text_block {\n  color: #123b67;\n  font-weight: 500;\n  font-size: 18px;\n}\n.Success_modal .icon_block {\n  color: #0fce0f;\n  font-size: 130px;\n}\n.parent_block {\n  background: transparent;\n  width: 100%;\n  height: 100%;\n  position: absolute;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3VjY2Vzcy1tb2RhbC9zdWNjZXNzLW1vZGFsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7RUFDQSxTQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0VBQ0EsNEJBQUE7RUFDQSw2QkFBQTtFQUNBLGFBQUE7QUFDSjtBQUFJO0VBQ0ksdUJBQUE7QUFFUjtBQUNJO0VBQ0ksY0FBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUNSO0FBQ0k7RUFDSSxjQUFBO0VBQ0osZ0JBQUE7QUFDSjtBQUdBO0VBQ0ksdUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBQUoiLCJmaWxlIjoic3JjL2FwcC9zdWNjZXNzLW1vZGFsL3N1Y2Nlc3MtbW9kYWwuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuU3VjY2Vzc19tb2RhbHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGJvdHRvbTogMDtcclxuICAgIGhlaWdodDogMjQwcHg7O1xyXG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAyMHB4O1xyXG4gICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDIwcHg7XHJcbiAgICBwYWRkaW5nOiAyMHB4O1xyXG4gICAgLm1vZGFsLXdyYXBwZXJ7XHJcbiAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcblxyXG4gICAgfVxyXG4gICAgLnRleHRfYmxvY2t7XHJcbiAgICAgICAgY29sb3I6ICMxMjNiNjc7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICB9XHJcbiAgICAuaWNvbl9ibG9ja3tcclxuICAgICAgICBjb2xvcjogIzBmY2UwZjtcclxuICAgIGZvbnQtc2l6ZTogMTMwcHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5wYXJlbnRfYmxvY2t7XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG59Il19 */");

/***/ }),

/***/ "./src/app/success-modal/success-modal.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/success-modal/success-modal.component.ts ***!
  \**********************************************************/
/*! exports provided: SuccessModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuccessModalComponent", function() { return SuccessModalComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");



let SuccessModalComponent = class SuccessModalComponent {
    constructor(modalController) {
        this.modalController = modalController;
    }
    ngOnInit() { }
    dismiss() {
        this.modalController.dismiss();
    }
};
SuccessModalComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
];
SuccessModalComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-success-modal',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./success-modal.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/success-modal/success-modal.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./success-modal.component.scss */ "./src/app/success-modal/success-modal.component.scss")).default]
    })
], SuccessModalComponent);



/***/ }),

/***/ "./src/app/support-complaint/new-complaint/new-complaint.component.scss":
/*!******************************************************************************!*\
  !*** ./src/app/support-complaint/new-complaint/new-complaint.component.scss ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".button_block {\n  padding-top: 50px;\n}\n\n.cust_id {\n  color: #123b67;\n  font-weight: 600;\n  padding-bottom: 14px;\n  text-align: left;\n  border-bottom: 1px solid #123b67;\n  margin-bottom: 4px;\n}\n\n.slect_box {\n  width: 100%;\n}\n\n.scheme_details {\n  background-color: #edf0f9;\n  color: #123b67;\n  font-weight: 600;\n  padding: 10px;\n  border-radius: 10px;\n}\n\n.info {\n  box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px, rgba(0, 0, 0, 0.14) 0px 2px 2px 0px, rgba(0, 0, 0, 0.12) 0px 1px 5px 0px;\n  min-height: 100px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3VwcG9ydC1jb21wbGFpbnQvbmV3LWNvbXBsYWludC9uZXctY29tcGxhaW50LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksaUJBQUE7QUFDSjs7QUFFQTtFQUNJLGNBQUE7RUFDQSxnQkFBQTtFQUNBLG9CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQ0FBQTtFQUNBLGtCQUFBO0FBQ0o7O0FBQ0E7RUFDSSxXQUFBO0FBRUo7O0FBQ0E7RUFDSSx5QkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQUVKOztBQUNBO0VBQ0kseUhBQUE7RUFDQSxpQkFBQTtBQUVKIiwiZmlsZSI6InNyYy9hcHAvc3VwcG9ydC1jb21wbGFpbnQvbmV3LWNvbXBsYWludC9uZXctY29tcGxhaW50LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJ1dHRvbl9ibG9ja3tcclxuICAgIHBhZGRpbmctdG9wOiA1MHB4O1xyXG59XHJcblxyXG4uY3VzdF9pZHtcclxuICAgIGNvbG9yOiAjMTIzYjY3O1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxNHB4O1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjMTIzYjY3O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNHB4O1xyXG59XHJcbi5zbGVjdF9ib3h7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG5cclxuLnNjaGVtZV9kZXRhaWxze1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjojZWRmMGY5O1xyXG4gICAgY29sb3I6ICMxMjNiNjc7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgcGFkZGluZzoxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxufVxyXG5cclxuLmluZm97XHJcbiAgICBib3gtc2hhZG93OiByZ2JhKDAsIDAsIDAsIDAuMikgMHB4IDNweCAxcHggLTJweCwgcmdiYSgwLCAwLCAwLCAwLjE0KSAwcHggMnB4IDJweCAwcHgsIHJnYmEoMCwgMCwgMCwgMC4xMikgMHB4IDFweCA1cHggMHB4O1xyXG4gICAgbWluLWhlaWdodDogMTAwcHg7XHJcbn0iXX0= */");

/***/ }),

/***/ "./src/app/support-complaint/new-complaint/new-complaint.component.ts":
/*!****************************************************************************!*\
  !*** ./src/app/support-complaint/new-complaint/new-complaint.component.ts ***!
  \****************************************************************************/
/*! exports provided: NewComplaintComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewComplaintComponent", function() { return NewComplaintComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");



let NewComplaintComponent = class NewComplaintComponent {
    constructor(navController, modalController) {
        this.navController = navController;
        this.modalController = modalController;
        this.customActionSheetOptions = {
            header: 'Schemes',
        };
    }
    ngOnInit() { }
    newComplaint() {
        console.log('new');
    }
    back() {
        this.navController.back();
    }
    changeEmail() {
    }
};
NewComplaintComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
];
NewComplaintComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-new-complaint',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./new-complaint.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/support-complaint/new-complaint/new-complaint.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./new-complaint.component.scss */ "./src/app/support-complaint/new-complaint/new-complaint.component.scss")).default]
    })
], NewComplaintComponent);



/***/ }),

/***/ "./src/app/support-complaint/support-complaint.component.scss":
/*!********************************************************************!*\
  !*** ./src/app/support-complaint/support-complaint.component.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".complaint_block {\n  background: #edf0f9;\n  padding: 10px;\n  border-radius: 10px;\n  margin-bottom: 15px;\n  align-items: center;\n  display: flex;\n  justify-content: space-between;\n}\n.complaint_block .closed {\n  color: red;\n}\n.complaint_block .open {\n  color: #4baaf3;\n}\n.label_text {\n  text-transform: uppercase;\n  font-weight: 600;\n  line-height: 24px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3VwcG9ydC1jb21wbGFpbnQvc3VwcG9ydC1jb21wbGFpbnQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7QUFDSjtBQUFJO0VBQ0ksVUFBQTtBQUVSO0FBQUk7RUFDQSxjQUFBO0FBRUo7QUFFQTtFQUNJLHlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQUNKIiwiZmlsZSI6InNyYy9hcHAvc3VwcG9ydC1jb21wbGFpbnQvc3VwcG9ydC1jb21wbGFpbnQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29tcGxhaW50X2Jsb2Nre1xyXG4gICAgYmFja2dyb3VuZDojZWRmMGY5O1xyXG4gICAgcGFkZGluZzoxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgIC5jbG9zZWR7XHJcbiAgICAgICAgY29sb3I6cmVkO1xyXG4gICAgfVxyXG4gICAgLm9wZW57XHJcbiAgICBjb2xvcjojNGJhYWYzXHJcbiAgICB9XHJcbn1cclxuXHJcbi5sYWJlbF90ZXh0e1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBsaW5lLWhlaWdodDogMjRweDtcclxufSJdfQ== */");

/***/ }),

/***/ "./src/app/support-complaint/support-complaint.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/support-complaint/support-complaint.component.ts ***!
  \******************************************************************/
/*! exports provided: SupportComplaintComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SupportComplaintComponent", function() { return SupportComplaintComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");



let SupportComplaintComponent = class SupportComplaintComponent {
    constructor(navController, modalController) {
        this.navController = navController;
        this.modalController = modalController;
        this.supportUrl = "https://www.bankofmaharashtra.in/pgrs/Existing_grievance";
        this.complaintUrl = "https://www.bankofmaharashtra.in/pgrs/Register_Grievance";
    }
    ngOnInit() { }
    add() {
        console.log('new');
        this.navController.navigateForward('newComplaint');
    }
    back() {
        this.navController.back();
    }
    openWindow(url) {
        window.open(url);
    }
};
SupportComplaintComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
];
SupportComplaintComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-support-complaint',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./support-complaint.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/support-complaint/support-complaint.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./support-complaint.component.scss */ "./src/app/support-complaint/support-complaint.component.scss")).default]
    })
], SupportComplaintComponent);



/***/ }),

/***/ "./src/app/verify-account/verify-account.component.scss":
/*!**************************************************************!*\
  !*** ./src/app/verify-account/verify-account.component.scss ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".button_block {\n  padding-top: 60px;\n}\n\n.not_recieved_otp_block {\n  padding: 20px;\n  color: #113A69;\n  font-weight: bold;\n  text-align: center;\n}\n\n.resend_txt {\n  display: block;\n  color: #113A69;\n  font-weight: bold;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdmVyaWZ5LWFjY291bnQvdmVyaWZ5LWFjY291bnQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxpQkFBQTtBQUNKOztBQUNBO0VBQ0ksYUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBRUo7O0FBQUE7RUFDSSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFHSiIsImZpbGUiOiJzcmMvYXBwL3ZlcmlmeS1hY2NvdW50L3ZlcmlmeS1hY2NvdW50LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJ1dHRvbl9ibG9ja3tcclxuICAgIHBhZGRpbmctdG9wOiA2MHB4O1xyXG59XHJcbi5ub3RfcmVjaWV2ZWRfb3RwX2Jsb2Nre1xyXG4gICAgcGFkZGluZzogMjBweDtcclxuICAgIGNvbG9yOiAjMTEzQTY5O1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuLnJlc2VuZF90eHR7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIGNvbG9yOiAjMTEzQTY5O1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn0iXX0= */");

/***/ }),

/***/ "./src/app/verify-account/verify-account.component.ts":
/*!************************************************************!*\
  !*** ./src/app/verify-account/verify-account.component.ts ***!
  \************************************************************/
/*! exports provided: VerifyAccountComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerifyAccountComponent", function() { return VerifyAccountComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _login_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../login.service */ "./src/app/login.service.ts");
/* harmony import */ var _customer_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../customer.service */ "./src/app/customer.service.ts");
/* harmony import */ var _common_service_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common/service/storage.service */ "./src/app/common/service/storage.service.ts");






let VerifyAccountComponent = class VerifyAccountComponent {
    constructor(navController, loginService, toastCtrl, customerService, storageSer) {
        this.navController = navController;
        this.loginService = loginService;
        this.toastCtrl = toastCtrl;
        this.customerService = customerService;
        this.storageSer = storageSer;
        this.OTP = {
            otp: ''
        };
        this.error = ' ';
        this.customer = {};
        this.customer.data = this.customerService.getCustomer();
        if (this.customer.data) {
            this.mobileNu = this.customer.data.data.mobileNu;
        }
    }
    ngOnInit() {
    }
    back() {
        this.navController.back();
    }
    resendOTP() {
        this.resend();
        this.presentActionSheet();
    }
    presentActionSheet() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastCtrl.create({
                message: 'OTP sent successfully',
                duration: 3000,
                position: 'bottom'
            });
            toast.onDidDismiss().then(data => {
                console.log('dismissed', data);
            });
            return yield toast.present();
        });
    }
    verify() {
        console.log('navController');
        if (this.OTP.otp) {
            this.loginService.verifyOTP(this.OTP)
                .subscribe((data) => {
                console.log("otp", data);
                if (data.status === 200) {
                    this.storageSer.setItem('AccountVerified', "true");
                    this.navController.navigateForward('login');
                }
                else {
                    this.error = data.error;
                    return;
                }
            });
        }
    }
    resend() {
        let userDetails = this.loginService.getregisterDetails();
        let req = {
            "accountNoCustNo": userDetails.accountNo,
            "mobileNo": userDetails.mobileNo
        };
        this.loginService.resendOTP(req)
            .subscribe((data) => {
        });
    }
};
VerifyAccountComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _login_service__WEBPACK_IMPORTED_MODULE_3__["LoginService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] },
    { type: _customer_service__WEBPACK_IMPORTED_MODULE_4__["CustomerService"] },
    { type: _common_service_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"] }
];
VerifyAccountComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-verify-account',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./verify-account.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/verify-account/verify-account.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./verify-account.component.scss */ "./src/app/verify-account/verify-account.component.scss")).default]
    })
], VerifyAccountComponent);



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/__ivy_ngcc__/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.log(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\Personal\Murali\Bank Of Maharastra\Client\BOM\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map